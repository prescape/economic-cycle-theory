# 周期罗盘 Multi-Version Runner V1.4.1

基于用户提供的两个抓取脚本修改规则重建。

- fetch_market_pit.py：930740 抓取失败时使用 000688 数据 proxy，source=akshare(000688_proxy)。
- fetch_macro_pit.py：credit_yoy 抓取失败不生成 demo；返回空表，并在输出已有 macro_pit.csv 时保留 last-good credit_yoy。
- 不修改 V7.5.1 / V7.28.4 / V7.28.5 策略参数。
