#!/usr/bin/env python3
"""
fetch_macro_pit.py — Dalio China V7.2 宏观数据采集（Point-in-Time）

采集项：GDP同比、PMI、CPI同比、PPI同比、社融存量同比、M2同比
PIT 字段：observation_date, release_date, available_date, source, data_quality
"""
import argparse
import sys
import re
from pathlib import Path
from datetime import datetime, timedelta

import pandas as pd

OUT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def _add_pit_meta(df: pd.DataFrame, source: str, quality: str) -> pd.DataFrame:
    """确保所有行都有 PIT 硬规则要求的字段。"""
    required = ["observation_date", "release_date", "available_date", "source", "data_quality"]
    for c in required:
        if c not in df.columns:
            raise ValueError(f"PIT column missing: {c}")
    df["observation_date"] = pd.to_datetime(df["observation_date"]).dt.strftime("%Y-%m-%d")
    df["release_date"] = pd.to_datetime(df["release_date"]).dt.strftime("%Y-%m-%d")
    df["available_date"] = pd.to_datetime(df["available_date"]).dt.strftime("%Y-%m-%d")
    df["revision_date"] = ""
    df["entity"] = "CN"
    # reorder
    return df[["entity", "feature", "observation_date", "release_date",
               "available_date", "revision_date", "value", "source", "data_quality"]]


def _try_akshare():
    try:
        import akshare as ak
        return ak
    except ImportError:
        return None


def _parse_chinese_date(s):
    """解析 '2026年07月份' / '2026年第1季度' 等中文日期。"""
    s = str(s)
    # 月份格式: 2026年07月份
    m = re.search(r'(\d{4})年(\d{2})月份', s)
    if m:
        return pd.Timestamp(f"{m.group(1)}-{m.group(2)}-01")
    # 季度格式: 2026年第1季度 或 2026年第1-2季度
    m = re.search(r'(\d{4})年第(\d+)[-]?\d*季度', s)
    if m:
        q = int(m.group(2))
        month = (q - 1) * 3 + 1
        return pd.Timestamp(f"{m.group(1)}-{month:02d}-01")
    return pd.Timestamp(s)


def fetch_gdp(ak) -> pd.DataFrame:
    """GDP 当季同比（国家统计局，发布时间滞后约15天）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.macro_china_gdp()
            # akshare 1.18+ 返回列：季度, 国内生产总值-绝对值, 国内生产总值-同比增长, ...
            for _, r in df.iterrows():
                obs = _parse_chinese_date(r["季度"])
                rel = obs + pd.Timedelta(days=18)
                rows.append({
                    "feature": "GDP_yoy",
                    "observation_date": obs,
                    "release_date": rel,
                    "available_date": rel,
                    "value": float(r["国内生产总值-同比增长"]),
                    "source": "NBS via akshare",
                    "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare GDP fetch failed: {e}", file=sys.stderr)
    if not rows:
        # fallback demo data
        for q in pd.date_range("2024-01-01", periods=10, freq="QS"):
            rows.append({
                "feature": "GDP_yoy",
                "observation_date": q,
                "release_date": q + pd.Timedelta(days=18),
                "available_date": q + pd.Timedelta(days=18),
                "value": 5.0 + (q.month % 3) * 0.2,
                "source": "NBS_demo",
                "data_quality": "A"
            })
    return _add_pit_meta(pd.DataFrame(rows), "NBS", "A")


def fetch_pmi(ak) -> pd.DataFrame:
    """官方制造业 PMI（每月最后一天发布上月数据，当月可用）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.macro_china_pmi()
            # akshare 1.18+ 返回列：月份, 制造业-指数, 制造业-同比增长, ...
            for _, r in df.iterrows():
                obs = _parse_chinese_date(r["月份"])
                rel = obs + pd.offsets.MonthEnd(0)
                rows.append({
                    "feature": "PMI",
                    "observation_date": obs,
                    "release_date": rel,
                    "available_date": rel,
                    "value": float(r["制造业-指数"]),
                    "source": "NBS via akshare",
                    "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare PMI fetch failed: {e}", file=sys.stderr)
    if not rows:
        for m in pd.date_range("2024-01-01", periods=18, freq="MS"):
            rows.append({
                "feature": "PMI",
                "observation_date": m,
                "release_date": m + pd.offsets.MonthEnd(0),
                "available_date": m + pd.offsets.MonthEnd(0),
                "value": 50.0 + (m.month % 3 - 1) * 0.5,
                "source": "NBS_demo",
                "data_quality": "A"
            })
    return _add_pit_meta(pd.DataFrame(rows), "NBS", "A")


def fetch_cpi(ak) -> pd.DataFrame:
    """CPI 同比（每月9-10日发布上月数据）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.macro_china_cpi()
            # akshare 1.18+ 返回列：月份, 全国-当月, 全国-同比增长, ...
            for _, r in df.iterrows():
                obs = _parse_chinese_date(r["月份"])
                rel = obs + pd.Timedelta(days=10)
                rows.append({
                    "feature": "CPI_yoy",
                    "observation_date": obs,
                    "release_date": rel,
                    "available_date": rel,
                    "value": float(r["全国-同比增长"]),
                    "source": "NBS via akshare",
                    "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare CPI fetch failed: {e}", file=sys.stderr)
    if not rows:
        for m in pd.date_range("2024-01-01", periods=18, freq="MS"):
            rows.append({
                "feature": "CPI_yoy",
                "observation_date": m,
                "release_date": m + pd.Timedelta(days=10),
                "available_date": m + pd.Timedelta(days=10),
                "value": 0.3 + (m.month % 6 - 3) * 0.1,
                "source": "NBS_demo",
                "data_quality": "A"
            })
    return _add_pit_meta(pd.DataFrame(rows), "NBS", "A")


def fetch_ppi(ak) -> pd.DataFrame:
    """PPI 同比（每月9-10日发布上月数据）。"""
    rows = []
    if ak is not None:
        try:
            df = ak.macro_china_ppi()
            # akshare 1.18+ 返回列：月份, 全国-当月, 全国-同比增长, ...
            for _, r in df.iterrows():
                obs = _parse_chinese_date(r["月份"])
                rel = obs + pd.Timedelta(days=10)
                rows.append({
                    "feature": "PPI_yoy",
                    "observation_date": obs,
                    "release_date": rel,
                    "available_date": rel,
                    "value": float(r["当月同比增长"]),
                    "source": "NBS via akshare",
                    "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare PPI fetch failed: {e}", file=sys.stderr)
    if not rows:
        for m in pd.date_range("2024-01-01", periods=18, freq="MS"):
            rows.append({
                "feature": "PPI_yoy",
                "observation_date": m,
                "release_date": m + pd.Timedelta(days=10),
                "available_date": m + pd.Timedelta(days=10),
                "value": -1.5 + (m.month % 6 - 3) * 0.2,
                "source": "NBS_demo",
                "data_quality": "A"
            })
    return _add_pit_meta(pd.DataFrame(rows), "NBS", "A")


def fetch_credit(ak) -> pd.DataFrame:
    """社会融资规模存量同比（央行每月10-15日发布上月数据）。"""
    rows = []
    if ak is not None:
        try:
            # 社融用 macro_china_shrzgm
            df = ak.macro_china_shrzgm()
            for _, r in df.iterrows():
                obs = _parse_chinese_date(r["月份"])
                rel = obs + pd.Timedelta(days=12)
                rows.append({
                    "feature": "credit_yoy",
                    "observation_date": obs,
                    "release_date": rel,
                    "available_date": rel,
                    "value": float(r.get("社会融资规模存量同比增长", 8.0)),
                    "source": "PBOC via akshare",
                    "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare credit fetch failed: {e}", file=sys.stderr)
    if not rows:
        print("[WARN] credit_yoy fetch failed/empty; no demo fallback, preserve existing data", file=sys.stderr)
        return pd.DataFrame(columns=[
            "entity", "feature", "observation_date", "release_date",
            "available_date", "revision_date", "value", "source", "data_quality"
        ])
    return _add_pit_meta(pd.DataFrame(rows), "PBOC", "A")


def fetch_m2(ak) -> pd.DataFrame:
    """M2 同比（央行每月10-15日发布上月数据）。"""
    rows = []
    if ak is not None:
        try:
            # akshare 1.18+ macro_china_m2_yearly 返回列：商品, 日期, 今值, 预测值, 前值
            df = ak.macro_china_m2_yearly()
            for _, r in df.iterrows():
                obs = pd.Timestamp(r["日期"])
                rel = obs + pd.Timedelta(days=12)
                rows.append({
                    "feature": "M2_yoy",
                    "observation_date": obs,
                    "release_date": rel,
                    "available_date": rel,
                    "value": float(r["今值"]),
                    "source": "PBOC via akshare",
                    "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare M2 fetch failed: {e}", file=sys.stderr)
    if not rows:
        for m in pd.date_range("2024-01-01", periods=18, freq="MS"):
            rows.append({
                "feature": "M2_yoy",
                "observation_date": m,
                "release_date": m + pd.Timedelta(days=12),
                "available_date": m + pd.Timedelta(days=12),
                "value": 7.0 + (m.month % 4 - 2) * 0.2,
                "source": "PBOC_demo",
                "data_quality": "A"
            })
    return _add_pit_meta(pd.DataFrame(rows), "PBOC", "A")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=str(OUT_DIR / "macro_pit.csv"))
    p.add_argument("--demo", action="store_true", help="强制使用示例数据")
    args = p.parse_args()

    ak = None if args.demo else _try_akshare()
    if ak is None:
        print("[INFO] 使用示例数据（akshare 不可用或 --demo 已指定）")

    credit_df = fetch_credit(ak)
    if credit_df.empty:
        out_path = Path(args.out)
        if out_path.exists():
            try:
                old_df = pd.read_csv(out_path)
                old_credit = old_df[old_df["feature"] == "credit_yoy"].copy()
                if not old_credit.empty:
                    credit_df = old_credit
                    print(f"[INFO] preserve existing credit_yoy rows: {len(old_credit)}", file=sys.stderr)
            except Exception as e:
                print(f"[WARN] preserve existing credit_yoy failed: {e}", file=sys.stderr)
    parts = [fetch_gdp(ak), fetch_pmi(ak), fetch_cpi(ak), fetch_ppi(ak), credit_df, fetch_m2(ak)]
    df = pd.concat(parts, ignore_index=True)
    if not args.demo and df["source"].astype(str).str.contains("demo", case=False, na=False).any():
        bad = sorted(df.loc[df["source"].astype(str).str.contains("demo", case=False, na=False), "feature"].unique().tolist())
        raise RuntimeError(f"V1.3 production forbids macro demo fallback; failed real features={bad}")
    df.to_csv(args.out, index=False)
    print(f"[OK] Macro PIT → {args.out} ({len(df)} rows)")


if __name__ == "__main__":
    main()
