#!/usr/bin/env python3
"""
fetch_market_pit.py — Dalio China V7.2 市场数据采集（Point-in-Time）

采集项：指数收盘价、成交额、换手率、波动率（20日）
覆盖 universe：000300, 000852, 399006, 000688, 000016, 930740
PIT 规则：T日收盘数据 available_date = T日
"""
import argparse
import sys
from pathlib import Path

import pandas as pd

OUT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"
OUT_DIR.mkdir(parents=True, exist_ok=True)

UNIVERSE = {
    "000300": "sh000300",
    "000852": "sh000852", 
    "399006": "sz399006",
    "000688": "sh000688",
    "000016": "sh000016",
    "930740": "sh930740",
}


def _add_pit_meta(df: pd.DataFrame) -> pd.DataFrame:
    required = ["entity", "feature", "observation_date", "release_date",
                "available_date", "value", "source", "data_quality"]
    for c in required:
        if c not in df.columns:
            raise ValueError(f"PIT column missing: {c}")
    df["observation_date"] = pd.to_datetime(df["observation_date"]).dt.strftime("%Y-%m-%d")
    df["release_date"] = pd.to_datetime(df["release_date"]).dt.strftime("%Y-%m-%d")
    df["available_date"] = pd.to_datetime(df["available_date"]).dt.strftime("%Y-%m-%d")
    df["revision_date"] = ""
    return df[["entity", "feature", "observation_date", "release_date",
               "available_date", "revision_date", "value", "source", "data_quality"]]


def _try_akshare():
    try:
        import akshare as ak
        return ak
    except ImportError:
        return None


def fetch_index_daily(ak, code: str, ak_code: str) -> pd.DataFrame:
    """获取指数日线数据。"""
    rows = []
    if ak is not None:
        try:
            df = ak.stock_zh_index_daily(symbol=ak_code)
            df['date'] = pd.to_datetime(df['date'])
            for _, r in df.iterrows():
                d = r["date"]
                rows.append({
                    "entity": code, "feature": "close",
                    "observation_date": d, "release_date": d,
                    "available_date": d, "value": float(r["close"]),
                    "source": "akshare", "data_quality": "A"
                })
                rows.append({
                    "entity": code, "feature": "volume",
                    "observation_date": d, "release_date": d,
                    "available_date": d, "value": int(r["volume"]),
                    "source": "akshare", "data_quality": "A"
                })
                # amount = volume * close 作为成交额 proxy
                amt = float(r["volume"]) * float(r["close"])
                rows.append({
                    "entity": code, "feature": "amount",
                    "observation_date": d, "release_date": d,
                    "available_date": d, "value": round(amt, 2),
                    "source": "akshare", "data_quality": "A"
                })
        except Exception as e:
            print(f"[WARN] akshare {code} failed: {e}", file=sys.stderr)
            # 930740 fallback 到 000688 数据（按用户提供文件）
            if code == "930740":
                try:
                    print("[INFO] 930740 fallback to 000688 data", file=sys.stderr)
                    df = ak.stock_zh_index_daily(symbol="sh000688")
                    df['date'] = pd.to_datetime(df['date'])
                    for _, r in df.iterrows():
                        d = r["date"]
                        rows.append({
                            "entity": code, "feature": "close",
                            "observation_date": d, "release_date": d,
                            "available_date": d, "value": float(r["close"]),
                            "source": "akshare(000688_proxy)", "data_quality": "A"
                        })
                        rows.append({
                            "entity": code, "feature": "volume",
                            "observation_date": d, "release_date": d,
                            "available_date": d, "value": int(r["volume"]),
                            "source": "akshare(000688_proxy)", "data_quality": "A"
                        })
                        amt = float(r["volume"]) * float(r["close"])
                        rows.append({
                            "entity": code, "feature": "amount",
                            "observation_date": d, "release_date": d,
                            "available_date": d, "value": round(amt, 2),
                            "source": "akshare(000688_proxy)", "data_quality": "A"
                        })
                except Exception as e2:
                    print(f"[WARN] 930740 fallback also failed: {e2}", file=sys.stderr)
    return pd.DataFrame(rows)


def _demo_ohlcv(code: str, start="2024-01-01", days=400) -> pd.DataFrame:
    """生成示例日线数据。"""
    rows = []
    base = {"000300": 3400, "000852": 5500, "399006": 1900,
            "000688": 900, "000016": 2400, "930740": 4200}[code]
    import random
    random.seed(42 + int(code))
    price = base
    for i in range(days):
        d = pd.Timestamp(start) + pd.Timedelta(days=i)
        if d.weekday() >= 5:
            continue
        price = price * (1 + random.gauss(0, 0.012))
        vol = random.randint(500000, 2000000)
        amt = vol * price
        rows.append({"entity": code, "feature": "close",
                     "observation_date": d, "release_date": d,
                     "available_date": d, "value": round(price, 4),
                     "source": "demo_exchange", "data_quality": "B"})
        rows.append({"entity": code, "feature": "volume",
                     "observation_date": d, "release_date": d,
                     "available_date": d, "value": vol,
                     "source": "demo_exchange", "data_quality": "B"})
        rows.append({"entity": code, "feature": "amount",
                     "observation_date": d, "release_date": d,
                     "available_date": d, "value": round(amt, 2),
                     "source": "demo_exchange", "data_quality": "B"})
    return pd.DataFrame(rows)


def calc_volatility(df: pd.DataFrame, window=20) -> pd.DataFrame:
    """基于已采集的 close 计算滚动波动率（T日可用）。"""
    closes = df[df["feature"] == "close"].copy()
    closes["observation_date"] = pd.to_datetime(closes["observation_date"])
    closes = closes.sort_values(["entity", "observation_date"])
    vol_rows = []
    for code, g in closes.groupby("entity"):
        g["ret"] = g["value"].pct_change()
        g["vol20"] = g["ret"].rolling(window).std() * (252 ** 0.5)
        for _, r in g.dropna(subset=["vol20"]).iterrows():
            vol_rows.append({
                "entity": code, "feature": "volatility_20d",
                "observation_date": r["observation_date"],
                "release_date": r["observation_date"],
                "available_date": r["observation_date"],
                "value": round(r["vol20"], 6),
                "source": "derived", "data_quality": "C"
            })
    return pd.DataFrame(vol_rows)


def calc_turnover(df: pd.DataFrame) -> pd.DataFrame:
    """基于 amount 估算换手率 proxy。"""
    amt = df[df["feature"] == "amount"].copy()
    amt["observation_date"] = pd.to_datetime(amt["observation_date"])
    to_rows = []
    for code, g in amt.groupby("entity"):
        for _, r in g.iterrows():
            to_rows.append({
                "entity": code, "feature": "turnover_proxy",
                "observation_date": r["observation_date"],
                "release_date": r["observation_date"],
                "available_date": r["observation_date"],
                "value": round(r["value"] / 1e10, 6),
                "source": "derived_proxy_amount", "data_quality": "C"
            })
    return pd.DataFrame(to_rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=str(OUT_DIR / "market_pit.csv"))
    p.add_argument("--demo", action="store_true")
    args = p.parse_args()

    ak = None if args.demo else _try_akshare()
    parts = []
    for code, ak_code in UNIVERSE.items():
        df = fetch_index_daily(ak, code, ak_code)
        if df.empty:
            if args.demo:
                print(f"[INFO] {code} 使用示例数据 (--demo only)")
                df = _demo_ohlcv(code)
            else:
                raise RuntimeError(f"real market fetch failed for {code}; demo fallback forbidden in V1.3 production")
        parts.append(df)

    base = pd.concat(parts, ignore_index=True)
    # 衍生指标
    parts.append(calc_volatility(base))
    parts.append(calc_turnover(base))

    df = pd.concat(parts, ignore_index=True)
    df = _add_pit_meta(df)
    df.to_csv(args.out, index=False)
    print(f"[OK] Market PIT → {args.out} ({len(df)} rows)")


if __name__ == "__main__":
    main()
