from pathlib import Path
import pandas as pd
import json, hashlib
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
LEDGER=ROOT/"oos"/"V7.28.4_OOS_LEDGER_APPEND_ONLY.csv"
HASHLOG=ROOT/"oos"/"OOS_APPEND_HASHCHAIN.csv"

REQUIRED=[
"node_id","decision_date","as_of_date","period_end","recorded_at","quadrant","regime","condition_active",
"breadth_000300","breadth_000852","breadth_399006","breadth_000688","breadth_000016",
"breadth_spread","breadth_dispersion","top_gap","bottom_gap","mean_pairwise_distance",
"breadth_top_asset","breadth_bottom_asset","tilt_delta",
"v751_net_return","v728_net_return","realized_incremental_alpha",
"oos_status","data_revision_flag","notes"
]

def append_node(row: dict):
    df=pd.read_csv(LEDGER)
    missing=[c for c in REQUIRED if c not in row]
    if missing:
        raise ValueError(f"Missing fields: {missing}")
    if len(df):
        if str(row["node_id"]) in df["node_id"].astype(str).tolist():
            raise ValueError("Duplicate node_id. Append a correction with a new node_id instead.")
        if str(row["decision_date"]) in df["decision_date"].astype(str).tolist() and not bool(row["data_revision_flag"]):
            raise ValueError("decision_date already exists; correction must use data_revision_flag=True.")
    expected = (str(row["quadrant"])=="Reflation") or (str(row["regime"])=="Risk-On")
    if bool(row["condition_active"]) != expected:
        raise ValueError("condition_active violates frozen Reflation OR Risk-On rule.")
    row["realized_incremental_alpha"]=float(row["v728_net_return"])-float(row["v751_net_return"])
    pd.DataFrame([row],columns=REQUIRED).to_csv(LEDGER,mode="a",header=False,index=False,encoding="utf-8-sig")

    payload=json.dumps(row,sort_keys=True,ensure_ascii=False,default=str)
    previous=""
    if HASHLOG.exists():
        h=pd.read_csv(HASHLOG)
        if len(h): previous=str(h.iloc[-1]["hash"])
    digest=hashlib.sha256((previous+payload).encode("utf-8")).hexdigest()
    pd.DataFrame([{
        "node_id":row["node_id"],"decision_date":row["decision_date"],
        "previous_hash":previous,"hash":digest,
        "appended_at_utc":datetime.now(timezone.utc).isoformat()
    }]).to_csv(HASHLOG,mode="a",header=not HASHLOG.exists(),index=False,encoding="utf-8-sig")
    return digest
