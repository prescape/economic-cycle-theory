from pathlib import Path
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
LEDGER=ROOT/"oos"/"V7.28.4_OOS_LEDGER_APPEND_ONLY.csv"
OUT=ROOT/"oos"/"OOS_LATEST_EVALUATION.csv"

def evaluate():
    df=pd.read_csv(LEDGER)
    if df.empty:
        out=pd.DataFrame([{"evaluable_nodes":0,"message":"No prospective OOS nodes recorded yet."}])
        out.to_csv(OUT,index=False,encoding="utf-8-sig")
        return out
    d=df[df["oos_status"].eq("EVALUATED")].copy()
    if d.empty:
        out=pd.DataFrame([{"evaluable_nodes":0,"message":"No evaluated prospective OOS nodes yet."}])
        out.to_csv(OUT,index=False,encoding="utf-8-sig")
        return out
    a=pd.to_numeric(d["realized_incremental_alpha"],errors="coerce")
    result={
      "evaluable_nodes":len(d),
      "active_nodes":int(d["condition_active"].astype(bool).sum()),
      "mean_incremental_alpha":a.mean(),
      "median_incremental_alpha":a.median(),
      "positive_rate":(a>0).mean(),
      "cumulative_simple_increment":a.sum()
    }
    for f in ["breadth_spread","breadth_dispersion","top_gap","bottom_gap","mean_pairwise_distance"]:
        x=pd.to_numeric(d[f],errors="coerce")
        z=pd.DataFrame({"x":x,"a":a}).dropna()
        result[f+"_spearman"]=z.x.corr(z.a,method="spearman") if len(z)>=3 else np.nan
    out=pd.DataFrame([result])
    out.to_csv(OUT,index=False,encoding="utf-8-sig")
    return out

if __name__=="__main__":
    print(evaluate().to_string(index=False))
