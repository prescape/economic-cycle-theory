"""周期罗盘 V7.28-EXPERIMENTAL-AlphaFusion Candidate

Frozen integration:
- Base alpha: V7.5.1 (55% valuation + 45% flow), unchanged.
- Conditional Breadth: Close / MA120 - 1, unchanged.
- Gate: quadrant == "Reflation" OR regime == "Risk-On", unchanged.
- Tilt: 10% of total risky allocation from lowest-ranked breadth asset
  to highest-ranked breadth asset, capped by donor asset weight.
- Risk allocation, V7.26 Risk Fusion and transaction cost convention unchanged.
- No parameter was tuned in V7.28.
"""
def conditional_breadth_enabled(quadrant, regime):
    return quadrant == "Reflation" or regime == "Risk-On"
