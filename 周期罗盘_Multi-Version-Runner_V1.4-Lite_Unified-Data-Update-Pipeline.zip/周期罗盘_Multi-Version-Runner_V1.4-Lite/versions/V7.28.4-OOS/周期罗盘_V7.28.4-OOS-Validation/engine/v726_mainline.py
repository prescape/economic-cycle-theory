"""
周期罗盘 V7.26-EXPERIMENTAL-Mainline
Pre-specified continuous risk fusion; no 132-node outcome-based tuning.

Architecture:
V7.5.1 Alpha/Regime -> V7.26 Continuous Risk Fusion -> 5-index weights
V7.20 Recovery / V7.22 CRQ4 remain Shadow/OOS diagnostics.

Rule:
persistence_intensity = systemic_persistence_score / 100
risk_severity = max(transmission_intensity, persistence_intensity)
risk_gap = max(0, v751_risk_allocation - v716_risk)
v726_risk = v751_risk_allocation - risk_severity * risk_gap

The risky-asset relative weights from V7.5.1 are preserved.
Only total risky allocation may be reduced.
"""
def v726_risk_budget(v751_risk, v716_risk, transmission_intensity,
                     systemic_persistence_score):
    persistence_intensity = max(0.0, min(1.0, systemic_persistence_score / 100.0))
    severity = max(max(0.0, min(1.0, transmission_intensity)),
                   persistence_intensity)
    gap = max(0.0, v751_risk - v716_risk)
    return v751_risk - severity * gap
