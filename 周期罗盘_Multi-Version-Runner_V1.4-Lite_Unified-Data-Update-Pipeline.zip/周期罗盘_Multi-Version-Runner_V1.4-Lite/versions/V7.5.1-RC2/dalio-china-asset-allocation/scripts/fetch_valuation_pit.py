#!/usr/bin/env python3
"""
fetch_valuation_pit.py — Dalio China V7.2 估值数据采集（Point-in-Time）

采集项：PE-TTM、PB、股息率、ERP（股权风险溢价）
覆盖 universe：000300, 000852, 399006, 000688, 000016, 930740

数据源优先级：
1. akshare stock_index_pe_lg / stock_index_pb_lg（实时，日度）
2. 对不支持的指数，用成分股计算或 proxy

PIT 规则：估值基于已公布财报，available_date = T日收盘后
"""
import argparse
import sys
from pathlib import Path

import pandas as pd
import numpy as np

OUT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"
OUT_DIR.mkdir(parents=True, exist_ok=True)

UNIVERSE = {
    "000300": {"name": "沪深300", "style": "large_core"},
    "000852": {"name": "中证1000", "style": "small_cap"},
    "399006": {"name": "创业板指", "style": "growth"},
    "000688": {"name": "科创50", "style": "technology_growth"},
    "000016": {"name": "上证50", "style": "mega_cap_value"},
    "930740": {"name": "300红利低波", "style": "dividend_defensive"},
}

# akshare stock_index_pe_lg 支持的指数名称映射
AK_PE_NAME_MAP = {
    "000300": "沪深300",
    "000852": None,  # 不支持
    "399006": None,  # 不支持
    "000688": None,  # 不支持
    "000016": "上证50",
    "930740": None,  # 不支持
}


def _add_pit_meta(df: pd.DataFrame) -> pd.DataFrame:
    required = ["entity", "feature", "observation_date", "release_date",
                "available_date", "value", "source", "data_quality"]
    for c in required:
        if c not in df.columns:
            raise ValueError(f"PIT column missing: {c}")
    df["observation_date"] = pd.to_datetime(df["observation_date"]).dt.strftime("%Y-%m-%d")
    df["release_date"] = pd.to_datetime(df["release_date"]).dt.strftime("%Y-%m-%d")
    df["available_date"] = pd.to_datetime(df["available_date"]).dt.strftime("%Y-%m-%d")
    df["revision_date"] = ""
    return df[["entity", "feature", "observation_date", "release_date",
               "available_date", "revision_date", "value", "source", "data_quality"]]


def _try_akshare():
    try:
        import akshare as ak
        return ak
    except ImportError:
        return None


def fetch_index_valuation_lg(ak, code: str) -> pd.DataFrame:
    """用乐估网接口获取指数估值（PE-TTM, PB）。"""
    rows = []
    name = AK_PE_NAME_MAP.get(code)
    if ak is None or name is None:
        return pd.DataFrame(rows)
    
    try:
        # PE
        df_pe = ak.stock_index_pe_lg(symbol=name)
        for _, r in df_pe.iterrows():
            d = pd.Timestamp(r["日期"])
            rows.append({
                "entity": code, "feature": "PE_TTM",
                "observation_date": d, "release_date": d,
                "available_date": d, "value": float(r["滚动市盈率"]),
                "source": "legu via akshare", "data_quality": "A"
            })
    except Exception as e:
        print(f"[WARN] PE fetch {code} failed: {e}", file=sys.stderr)
    
    try:
        # PB
        df_pb = ak.stock_index_pb_lg(symbol=name)
        for _, r in df_pb.iterrows():
            d = pd.Timestamp(r["日期"])
            rows.append({
                "entity": code, "feature": "PB",
                "observation_date": d, "release_date": d,
                "available_date": d, "value": float(r["市净率"]),
                "source": "legu via akshare", "data_quality": "A"
            })
    except Exception as e:
        print(f"[WARN] PB fetch {code} failed: {e}", file=sys.stderr)
    
    return pd.DataFrame(rows)


def _calc_proxy_valuation(code: str, close_df: pd.DataFrame) -> pd.DataFrame:
    """
    对不支持 akshare 估值接口的指数，用 proxy 计算估值。
    方法：基于 close 走势和已知指数的历史 PE-PB 关系推算。
    """
    rows = []
    # 各指数长期估值中枢（PE-TTM）
    pe_mean = {"000300": 12.5, "000852": 35.0, "399006": 45.0,
               "000688": 55.0, "000016": 10.0, "930740": 8.5}[code]
    
    # 用价格相对 250 日均线的偏离度作为估值 proxy
    # market_pit.csv 的 entity 可能是整数格式（300, 852）
    code_int = int(code) if code.isdigit() else code
    closes = close_df[(close_df["entity"] == code) | (close_df["entity"] == code_int)].copy()
    if closes.empty:
        return pd.DataFrame(rows)
    
    closes["observation_date"] = pd.to_datetime(closes["observation_date"])
    closes = closes.sort_values("observation_date")
    closes["ma250"] = closes["value"].rolling(250).mean()
    closes["deviation"] = closes["value"] / closes["ma250"] - 1
    
    # 偏离度映射到 PE：偏离 0 = pe_mean，偏离 +20% = pe_mean * 1.3，偏离 -20% = pe_mean * 0.7
    import random
    random.seed(2024 + int(code))
    for _, r in closes.dropna(subset=["deviation"]).iterrows():
        d = r["observation_date"]
        pe = pe_mean * (1 + r["deviation"] * 1.5)
        pb = pe / random.uniform(1.8, 2.8)
        dy = 0.03 if code == "930740" else (0.01 if "300" in code else 0.015)
        
        rows.append({
            "entity": code, "feature": "PE_TTM",
            "observation_date": d, "release_date": d,
            "available_date": d, "value": round(max(pe, 1), 4),
            "source": "derived_proxy", "data_quality": "D"
        })
        rows.append({
            "entity": code, "feature": "PB",
            "observation_date": d, "release_date": d,
            "available_date": d, "value": round(max(pb, 0.5), 4),
            "source": "derived_proxy", "data_quality": "D"
        })
        rows.append({
            "entity": code, "feature": "dividend_yield",
            "observation_date": d, "release_date": d,
            "available_date": d, "value": round(dy, 6),
            "source": "derived_proxy", "data_quality": "D"
        })
    return pd.DataFrame(rows)


def _demo_valuation(code: str, start="2024-01-01", days=400) -> pd.DataFrame:
    """生成示例估值数据。"""
    rows = []
    pe_mean = {"000300": 12.5, "000852": 35.0, "399006": 45.0,
               "000688": 55.0, "000016": 10.0, "930740": 8.5}[code]
    import random
    random.seed(2024 + int(code))
    pe = pe_mean
    for i in range(days):
        d = pd.Timestamp(start) + pd.Timedelta(days=i)
        if d.weekday() >= 5:
            continue
        pe = pe + random.gauss(0, 0.15) + (pe_mean - pe) * 0.01
        pb = pe / random.uniform(1.8, 2.8)
        dy = random.uniform(0.015, 0.035) if "红利" in code else random.uniform(0.008, 0.025)
        rows.append({"entity": code, "feature": "PE_TTM",
                     "observation_date": d, "release_date": d,
                     "available_date": d, "value": round(pe, 4),
                     "source": "derived_demo", "data_quality": "C"})
        rows.append({"entity": code, "feature": "PB",
                     "observation_date": d, "release_date": d,
                     "available_date": d, "value": round(pb, 4),
                     "source": "derived_demo", "data_quality": "C"})
        rows.append({"entity": code, "feature": "dividend_yield",
                     "observation_date": d, "release_date": d,
                     "available_date": d, "value": round(dy, 6),
                     "source": "derived_demo", "data_quality": "C"})
    return pd.DataFrame(rows)


def calc_erp(df: pd.DataFrame, bond_yield: float = 0.025) -> pd.DataFrame:
    """计算股权风险溢价 ERP = 1/PE - 10Y国债收益率。"""
    pe = df[df["feature"] == "PE_TTM"].copy()
    pe["observation_date"] = pd.to_datetime(pe["observation_date"])
    erp_rows = []
    for code, g in pe.groupby("entity"):
        for _, r in g.iterrows():
            erp = 1.0 / r["value"] - bond_yield
            erp_rows.append({
                "entity": code, "feature": "ERP",
                "observation_date": r["observation_date"],
                "release_date": r["observation_date"],
                "available_date": r["observation_date"],
                "value": round(erp, 6),
                "source": "derived", "data_quality": "C"
            })
    return pd.DataFrame(erp_rows)


def calc_relative_valuation(df: pd.DataFrame) -> pd.DataFrame:
    """相对估值分位数（基于历史5年）。"""
    pe = df[df["feature"] == "PE_TTM"].copy()
    pe["observation_date"] = pd.to_datetime(pe["observation_date"])
    pe = pe.sort_values(["entity", "observation_date"])
    rv_rows = []
    for code, g in pe.groupby("entity"):
        g["PE_percentile"] = g["value"].rolling(min_periods=60, window=252*5).apply(
            lambda x: (x <= x.iloc[-1]).mean(), raw=False)
        for _, r in g.dropna(subset=["PE_percentile"]).iterrows():
            rv_rows.append({
                "entity": code, "feature": "relative_valuation",
                "observation_date": r["observation_date"],
                "release_date": r["observation_date"],
                "available_date": r["observation_date"],
                "value": round(r["PE_percentile"], 6),
                "source": "derived", "data_quality": "C"
            })
    return pd.DataFrame(rv_rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=str(OUT_DIR / "valuation_pit.csv"))
    p.add_argument("--demo", action="store_true")
    p.add_argument("--bond-yield", type=float, default=0.025, help="10Y国债收益率，用于ERP计算")
    p.add_argument("--market-pit", default=str(OUT_DIR / "market_pit.csv"),
                   help="市场数据PIT文件路径，用于proxy估值计算")
    args = p.parse_args()

    ak = None if args.demo else _try_akshare()
    parts = []
    
    # 读取市场数据（用于 proxy 估值）
    market_df = None
    if Path(args.market_pit).exists():
        market_df = pd.read_csv(args.market_pit)
        market_df = market_df[market_df["feature"] == "close"][["entity", "observation_date", "value"]]
    
    for code in UNIVERSE:
        # 先尝试 akshare 实时接口
        df = fetch_index_valuation_lg(ak, code)
        if df.empty:
            #  fallback：用 market proxy 或 demo
            if market_df is not None and not args.demo:
                print(f"[INFO] {code} 用 market proxy 计算估值")
                df = _calc_proxy_valuation(code, market_df)
            if df.empty:
                print(f"[INFO] {code} 使用示例估值数据")
                df = _demo_valuation(code)
        parts.append(df)

    base = pd.concat(parts, ignore_index=True)
    parts.append(calc_erp(base, args.bond_yield))
    parts.append(calc_relative_valuation(base))

    df = pd.concat(parts, ignore_index=True)
    df = _add_pit_meta(df)
    df.to_csv(args.out, index=False)
    print(f"[OK] Valuation PIT → {args.out} ({len(df)} rows)")
    
    # 打印最新数据
    latest = df.copy()
    latest["observation_date"] = pd.to_datetime(latest["observation_date"])
    max_date = latest["observation_date"].max()
    print(f"\nLatest data: {max_date.strftime('%Y-%m-%d')}")
    summary = latest[latest["observation_date"] == max_date][["entity", "feature", "value", "source"]]
    for feat in ["PE_TTM", "PB"]:
        sub = summary[summary["feature"] == feat]
        if not sub.empty:
            print(f"\n{feat}:")
            for _, r in sub.iterrows():
                print(f"  {r['entity']}: {r['value']:.2f} ({r['source']})")


if __name__ == "__main__":
    main()
