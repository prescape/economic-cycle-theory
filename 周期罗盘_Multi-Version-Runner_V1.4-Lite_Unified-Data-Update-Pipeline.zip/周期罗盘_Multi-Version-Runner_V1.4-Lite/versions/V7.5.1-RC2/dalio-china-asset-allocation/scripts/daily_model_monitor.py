#!/usr/bin/env python3
"""
daily_model_monitor.py — V7.5.1 每日收盘模型监控

执行逻辑：
1. 加载截止今日的最新 PIT 数据 (unified_pit.csv)
2. 运行 V7.5.1 宏观引擎计算当前 Regime
3. 读取 factor_panel 计算 Alpha 权重
4. 对比昨日/上次记录，检测变化
5. 如 Regime 切换、Top1 变更、任一资产权重变化 >2%，则生成报告并推送

推送目标：openclaw-weixin
数据截止：当日收盘后（默认 20:00 执行）
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta

BASE = Path(__file__).resolve().parents[1]
PIT_DIR = BASE / "data" / "pit"
REF_DIR = BASE / "data" / "reference"
STATE_PATH = BASE / "data" / "daily_monitor_state.json"
REPORT_PATH = BASE / "data" / "daily_monitor_report.txt"

ASSETS = ["000300", "000852", "399006", "000688", "000016"]
INDEX_MAP = {
    "000300": "沪深300",
    "000852": "中证1000",
    "399006": "创业板指",
    "000688": "科创50",
    "000016": "上证50",
    "930740": "300红利低波",
}
RANK_POINTS = np.array([5, 4, 3, 2, 1], dtype=float)
REGIME_ALLOC = {"Risk-On": 0.80, "Neutral": 0.55, "Risk-Off": 0.30}
REGIME_LEVEL = {"Risk-Off": 0, "Neutral": 1, "Risk-On": 2}
LEVEL_REGIME = {0: "Risk-Off", 1: "Neutral", 2: "Risk-On"}


def norm_code(x):
    s = str(x).strip()
    if s.endswith(".0") and s[:-2].isdigit():
        s = s[:-2]
    if s.isdigit() and len(s) < 6:
        s = s.zfill(6)
    return s


def hist_series(d, feature, entity, asof):
    q = d[
        (d.feature == feature)
        & (d.entity == entity)
        & (d.available_date <= asof)
        & (d.observation_date <= asof)
    ].copy()
    q = q.dropna(subset=["observation_date", "value"]).sort_values(
        ["observation_date", "available_date"]
    )
    q = q.drop_duplicates("observation_date", keep="last")
    return q.set_index("observation_date").value.astype(float)


def lastv(s):
    return float(s.iloc[-1]) if len(s) else np.nan


def delta_months(s, months):
    if len(s) < 2:
        return np.nan
    cutoff = s.index[-1] - pd.DateOffset(months=months)
    p = s[s.index <= cutoff]
    return float(s.iloc[-1] - p.iloc[-1]) if len(p) else np.nan


def build_macro_v75(d, asof):
    """V7.5.1 宏观引擎"""
    pmi = hist_series(d, "PMI", "CN", asof)
    cpi = hist_series(d, "CPI_yoy", "CN", asof)
    ppi = hist_series(d, "PPI_yoy", "CN", asof)
    m2 = hist_series(d, "M2_yoy", "CN", asof)
    gdp = hist_series(d, "GDP_yoy", "CN", asof)
    lpr = hist_series(d, "LPR_1Y", "CN", asof)
    rrr = hist_series(d, "RRR_change", "CN", asof)

    pv, pd3 = lastv(pmi), delta_months(pmi, 3)
    cv, cd3 = lastv(cpi), delta_months(cpi, 3)
    ppv, ppd3 = lastv(ppi), delta_months(ppi, 3)
    mv, md3 = lastv(m2), delta_months(m2, 3)

    lpr6 = delta_months(lpr, 6)
    recent = rrr[rrr.index >= asof - pd.Timedelta(days=180)]
    pol = 0.0
    if np.isfinite(lpr6):
        pol += 0.6 * np.clip(-lpr6 / 0.0025, -1, 1)
    if len(recent):
        pol += 0.4 * np.clip(-float(recent.sum()) / 0.5, -1, 1)

    gu = bool(np.isfinite(pv) and np.isfinite(pd3) and pv >= 50 and pd3 >= 0)
    gw = bool(
        np.isfinite(pv) and np.isfinite(pd3) and (pv < 50 or pd3 <= -0.5)
    )

    parts = []
    if np.isfinite(cd3):
        parts.append(cd3)
    if np.isfinite(ppd3):
        parts.append(ppd3 / 3)
    idir = float(np.mean(parts)) if parts else 0.0
    iu, idd = idir > 0.15, idir < -0.15

    if gu and idd:
        q = "Goldilocks"
    elif gu and iu:
        q = "Reflation"
    elif gw and iu:
        q = "Stagflation"
    elif gw and idd:
        q = "Deflation"
    else:
        q = "Mixed"

    cw = bool(np.isfinite(md3) and md3 < 0)
    cs = bool(np.isfinite(md3) and md3 >= 0)

    s = hist_series(d, "close", "000300", asof)
    price = float(s.iloc[-1])
    ma120 = float(s.iloc[-120:].mean())
    r20 = float(price / s.iloc[-21] - 1) if len(s) >= 21 else np.nan
    r60 = float(price / s.iloc[-61] - 1) if len(s) >= 61 else np.nan
    below = price < ma120

    desired = "Neutral"
    if gu and cs and (not below) and r60 > 0:
        desired = "Risk-On"
    if gw and (cw or q == "Stagflation") and r60 <= 0:
        desired = "Risk-Off"
    if below and r20 < 0:
        desired = "Risk-Off"

    return {
        "quadrant": q,
        "desired_regime": desired,
        "GDP_yoy": lastv(gdp),
        "PMI": pv,
        "PMI_3m_change": pd3,
        "CPI_yoy": cv,
        "CPI_3m_change": cd3,
        "PPI_yoy": ppv,
        "PPI_3m_change": ppd3,
        "M2_yoy": mv,
        "M2_3m_change": md3,
        "policy_easing_score": pol,
        "CSI300_MA120": ma120,
        "CSI300_ret20": r20,
        "CSI300_ret60": r60,
        "CSI300_below_MA120": below,
    }


def get_latest_factor_panel():
    """读取 factor_panel 最新一期数据"""
    p = pd.read_csv(REF_DIR / "V7.3_factor_panel_completed.csv")
    p["decision_date"] = pd.to_datetime(p["decision_date"])
    p["as_of_date"] = pd.to_datetime(p["as_of_date"])
    p["asset"] = p["asset"].map(norm_code)

    latest_date = p["decision_date"].max()
    latest = p[p["decision_date"] == latest_date].set_index("asset").reindex(ASSETS)

    # V7.5.1 alpha: 55% valuation + 45% fund flow
    latest = latest.copy()
    latest["alpha_v75"] = 0.55 * latest["valuation"] + 0.45 * latest["flow"]

    return latest, latest_date


def compute_weights(alpha_series, regime, prev_weights=None):
    """计算配置权重（V7.5.1 逻辑）"""
    risk = REGIME_ALLOC[regime]
    ranked = alpha_series.sort_values(ascending=False)
    raw = {a: 0.0 for a in ASSETS}
    for pts, a in zip(RANK_POINTS, ranked.index):
        raw[a] = risk * pts / RANK_POINTS.sum()

    if prev_weights:
        blend = {a: 0.5 * prev_weights.get(a, 0.0) + 0.5 * raw[a] for a in ASSETS}
        ss = sum(blend.values())
        w = {a: blend[a] * risk / ss for a in ASSETS}
    else:
        w = raw.copy()

    cash = 1 - sum(w.values())
    return w, cash


def load_state():
    if STATE_PATH.exists():
        with open(STATE_PATH) as f:
            return json.load(f)
    return None


def save_state(state):
    with open(STATE_PATH, "w") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def generate_report(ts, cfg, current, prev, data_date):
    lines = [
        f"📊【V7.5.1 每日模型监控】",
        f"数据截止: {data_date}",
        "",
        f"🚀 宏观Regime: {cfg['regime']}",
        f"   象限: {cfg['quadrant']}",
        f"   PMI={cfg['PMI']:.1f} (3月变化={cfg['PMI_3m_change']:+.2f})",
        f"   M2={cfg['M2_yoy']:.2f}% (3月变化={cfg['M2_3m_change']:+.2f})",
        f"   政策宽松度={cfg['policy_easing_score']:+.2f}",
        f"   CSI300 20日收益={cfg['CSI300_ret20']:.2%}",
        f"   沪深300低于120日均线: {'是' if cfg['CSI300_below_MA120'] else '否'}",
        "",
        f"📈 配置权重 (Risk Budget={REGIME_ALLOC[cfg['regime']]:.0%}):",
    ]

    sorted_assets = sorted(current["weights"].items(), key=lambda x: -x[1])
    medals = ["🥇", "🥈", "🥉", "  ", "  "]
    for i, (code, w) in enumerate(sorted_assets):
        name = INDEX_MAP.get(code, code)
        lines.append(f"  {medals[i] if i < 5 else '  '} {name:12s}: {w:6.2%}")

    lines.append(f"\n💰 现金: {current['cash']:.2%}")
    lines.append(f"\n🏆 Top Pick: {INDEX_MAP.get(sorted_assets[0][0], sorted_assets[0][0])} ({sorted_assets[0][1]:.2%})")

    if prev:
        lines.append("\n📊 对比上次:")
        for code in ASSETS:
            name = INDEX_MAP.get(code, code)
            delta = current["weights"][code] - prev["weights"].get(code, 0)
            if abs(delta) >= 0.001:
                arrow = "↑" if delta > 0 else "↓"
                lines.append(f"  {name}: {prev['weights'].get(code, 0):.2%} → {current['weights'][code]:.2%} ({arrow}{abs(delta):.2%})")
        if prev.get("regime") != cfg["regime"]:
            lines.append(f"\n⚠️ Regime 切换: {prev.get('regime', 'N/A')} → {cfg['regime']}")

    return "\n".join(lines)


def main():
    print("=" * 60)
    print("V7.5.1 Daily Model Monitor")
    print(f"执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("=" * 60)

    # 加载 PIT 数据
    d = pd.read_csv(PIT_DIR / "unified_pit.csv", low_memory=False)
    d["entity"] = d["entity"].map(norm_code)
    d["observation_date"] = pd.to_datetime(d["observation_date"], errors="coerce")
    d["available_date"] = pd.to_datetime(d["available_date"], errors="coerce")
    d["value"] = pd.to_numeric(d["value"], errors="coerce")

    # 使用最新 available_date 作为决策基准
    data_date = d["available_date"].max().strftime("%Y-%m-%d")
    asof = pd.Timestamp(data_date)
    print(f"\n数据最新日期: {data_date}")

    # 计算宏观状态
    macro = build_macro_v75(d, asof)

    # 加载 factor panel
    try:
        panel, panel_date = get_latest_factor_panel()
        print(f"Factor panel 最新日期: {panel_date.strftime('%Y-%m-%d')}")
    except Exception as e:
        print(f"[WARN] 无法加载 factor panel: {e}")
        panel = None

    # 确定 regime（使用状态机逻辑）
    prev_state = load_state()
    prev_regime = prev_state["regime"] if prev_state else "Neutral"

    desired = macro["desired_regime"]
    cur_level = REGIME_LEVEL[prev_regime]
    des_level = REGIME_LEVEL[desired]

    # 非对称滞后：下降立即，上升需要两次连续确认
    if des_level < cur_level:
        regime = desired
        up_count = 0
    elif des_level > cur_level:
        up_count = prev_state.get("up_count", 0) if prev_state else 0
        prev_des = prev_state.get("prev_desired") if prev_state else None
        if desired == prev_des:
            up_count += 1
        else:
            up_count = 1
        if up_count >= 2:
            regime = LEVEL_REGIME[min(cur_level + 1, des_level)]
            up_count = 0
        else:
            regime = prev_regime
    else:
        regime = prev_regime
        up_count = 0

    macro["regime"] = regime
    macro["up_count"] = up_count
    macro["prev_desired"] = desired

    # 计算权重
    if panel is not None:
        alpha = panel["alpha_v75"].dropna()
        prev_weights = prev_state["weights"] if prev_state else None
        weights, cash = compute_weights(alpha, regime, prev_weights)
    else:
        weights = {a: 0.0 for a in ASSETS}
        cash = 1.0

    current = {
        "timestamp": datetime.now().isoformat(),
        "data_date": data_date,
        "panel_date": panel_date.strftime("%Y-%m-%d") if panel is not None else None,
        "regime": regime,
        "weights": weights,
        "cash": cash,
        "macro": macro,
    }

    # 检测变化
    should_alert = False
    alert_reasons = []

    if prev_state:
        if prev_state.get("regime") != regime:
            should_alert = True
            alert_reasons.append(f"Regime切换 {prev_state.get('regime','?')}→{regime}")

        prev_top = max(prev_state.get("weights", {}), key=prev_state["weights"].get, default="")
        curr_top = max(weights, key=weights.get)
        if prev_top != curr_top:
            should_alert = True
            alert_reasons.append(f"Top1变更 {INDEX_MAP.get(prev_top,prev_top)}→{INDEX_MAP.get(curr_top,curr_top)}")

        for code in ASSETS:
            delta = abs(weights[code] - prev_state.get("weights", {}).get(code, 0))
            if delta > 0.02:
                should_alert = True
                name = INDEX_MAP.get(code, code)
                alert_reasons.append(f"{name}权重变化{delta:.1%}")

    # 生成报告
    report = generate_report(datetime.now(), macro, current, prev_state, data_date)

    # 保存到文件
    with open(REPORT_PATH, "w") as f:
        f.write(report)

    # 保存状态
    save_state(current)

    print(f"\n{report}")

    if should_alert:
        print(f"\n🔔 信号变化触发推送: {', '.join(alert_reasons[:3])}")
        print("\n---PUSH_START---")
        print(report)
        print("---PUSH_END---")
    else:
        print("\n✅ 信号无显著变化，静默更新")

    print(f"\n状态已保存: {STATE_PATH}")

    # ===== 月末自动执行半月频回测 =====
    today = datetime.now()
    tomorrow = today + timedelta(days=1)
    if tomorrow.day == 1:
        print(f"\n📅 今日为月末 ({today.strftime('%Y-%m-%d')})，自动执行半月频回测...")
        import subprocess

        biweekly_script = Path(__file__).resolve().parent / "walkforward_v72_biweekly.py"
        if biweekly_script.exists():
            result = subprocess.run(
                [sys.executable, str(biweekly_script)],
                capture_output=True,
                text=True,
                cwd=str(Path(__file__).resolve().parents[1]),
            )
            if result.returncode == 0:
                print("✅ 半月频回测完成")
            else:
                print(f"❌ 半月频回测失败: {result.stderr[:200]}")
        else:
            print(f"⚠️ 未找到半月频脚本: {biweekly_script}")


if __name__ == "__main__":
    main()
