#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_missing_history_v7_3.py
--------------------------------
Dalio China Asset Allocation V7.3 缺失历史数据补齐脚本

目标
1) 抓取 930740（300红利低波）真实历史日线，替换 demo_exchange。
2) 抓取 2021-2024 历史业绩快报，并生成 PIT-safe 的
   earnings_growth_yoy / earnings_revision_1m / earnings_revision_3m。
3) 不修改任何 V7.3 模型权重。
4) 不使用未来数据回填历史。
5) 默认不使用“当前指数成分权重”重构历史指数盈利，避免幸存者偏差。
   如提供历史权重目录，则按历史权重做指数级盈利聚合。
6) 输出覆盖率报告，并可选择合并回现有 market_pit.csv /
   earnings_pit.csv / unified_pit.csv。

依赖
    pip install -U akshare pandas numpy

推荐运行位置
    <skill_root>/scripts/fetch_missing_history_v7_3.py

示例
    python scripts/fetch_missing_history_v7_3.py

    # 指定回测预热起点与结束日期
    python scripts/fetch_missing_history_v7_3.py \
        --market-start 20200101 \
        --market-end 20260630 \
        --earnings-start-year 2021 \
        --earnings-end-year 2024

    # 如已有“历史指数权重”CSV目录，可生成指数级历史盈利
    python scripts/fetch_missing_history_v7_3.py \
        --historical-weights-dir data/historical_index_weights

历史权重CSV建议字段
    index_code, stock_code, weight, effective_date

其中 effective_date 表示该组权重开始可用于当时决策的日期。
脚本只会在 earnings announcement_date 当日向后找最近一个
effective_date <= announcement_date 的权重快照，绝不使用未来权重。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd


BASE = Path(__file__).resolve().parents[1]
PIT_DIR = BASE / "data" / "pit"
PIT_DIR.mkdir(parents=True, exist_ok=True)

UNIVERSE = ["000300", "000852", "399006", "000688", "000016", "930740"]
TARGET_INDEX = "930740"

PIT_COLUMNS = [
    "entity", "feature", "observation_date", "release_date",
    "available_date", "revision_date", "value", "source", "data_quality"
]


def _try_akshare():
    try:
        import akshare as ak
        return ak
    except ImportError as exc:
        raise RuntimeError(
            "未安装 akshare。请先执行: pip install -U akshare"
        ) from exc


def _normalize_date_col(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, errors="coerce").dt.strftime("%Y-%m-%d")


def _ensure_pit(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    required = [
        "entity", "feature", "observation_date",
        "release_date", "available_date",
        "value", "source", "data_quality"
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"PIT columns missing: {missing}")

    df["observation_date"] = _normalize_date_col(df["observation_date"])
    df["release_date"] = _normalize_date_col(df["release_date"])
    df["available_date"] = _normalize_date_col(df["available_date"])

    if "revision_date" not in df.columns:
        df["revision_date"] = ""

    df["entity"] = df["entity"].astype(str).str.zfill(6)
    df.loc[df["entity"].eq("0000CN"), "entity"] = "CN"

    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    df = df.dropna(subset=["observation_date", "release_date", "available_date", "value"])
    return df[PIT_COLUMNS]


# ============================================================
# 1. 930740 真实历史行情
# ============================================================

def _fetch_930740_csindex(ak, start_date: str, end_date: str) -> pd.DataFrame:
    """
    首选中证指数官方数据接口（经 AKShare）：
        stock_zh_index_hist_csindex(symbol="930740", ...)
    """
    try:
        raw = ak.stock_zh_index_hist_csindex(
            symbol=TARGET_INDEX,
            start_date=start_date,
            end_date=end_date,
        )
    except Exception as exc:
        print(f"[WARN] CSIndex 930740 fetch failed: {exc}", file=sys.stderr)
        return pd.DataFrame()

    if raw is None or raw.empty:
        return pd.DataFrame()

    rename = {
        "日期": "date",
        "开盘": "open",
        "最高": "high",
        "最低": "low",
        "收盘": "close",
        "成交量": "volume",
        "成交金额": "amount",
    }
    raw = raw.rename(columns=rename)

    needed = {"date", "close"}
    if not needed.issubset(raw.columns):
        print(
            f"[WARN] CSIndex returned unexpected columns: {list(raw.columns)}",
            file=sys.stderr,
        )
        return pd.DataFrame()

    raw["date"] = pd.to_datetime(raw["date"], errors="coerce")
    raw = raw.dropna(subset=["date", "close"]).sort_values("date")
    raw = raw[
        (raw["date"] >= pd.Timestamp(start_date)) &
        (raw["date"] <= pd.Timestamp(end_date))
    ].copy()

    # 中证接口文档：成交量单位为“万手”，成交金额单位为“亿元”。
    # 统一转换为较接近其他 market_pit 的原始尺度：
    # volume -> 手；amount -> 元
    if "volume" in raw.columns:
        raw["volume"] = pd.to_numeric(raw["volume"], errors="coerce") * 10000
    if "amount" in raw.columns:
        raw["amount"] = pd.to_numeric(raw["amount"], errors="coerce") * 1e8

    return raw


def _fetch_930740_eastmoney(ak, start_date: str, end_date: str) -> pd.DataFrame:
    """
    备用真实行情源：东方财富指数日线（经 AKShare）。
    中证指数使用 csi + 指数代码。
    """
    try:
        raw = ak.stock_zh_index_daily_em(
            symbol=f"csi{TARGET_INDEX}",
            start_date=start_date,
            end_date=end_date,
        )
    except Exception as exc:
        print(f"[WARN] Eastmoney 930740 fetch failed: {exc}", file=sys.stderr)
        return pd.DataFrame()

    if raw is None or raw.empty:
        return pd.DataFrame()

    raw = raw.copy()
    if "date" not in raw.columns or "close" not in raw.columns:
        print(
            f"[WARN] Eastmoney returned unexpected columns: {list(raw.columns)}",
            file=sys.stderr,
        )
        return pd.DataFrame()

    raw["date"] = pd.to_datetime(raw["date"], errors="coerce")
    raw = raw.dropna(subset=["date", "close"]).sort_values("date")
    return raw


def _market_rows_from_raw(raw: pd.DataFrame, source: str) -> pd.DataFrame:
    if raw.empty:
        return pd.DataFrame(columns=PIT_COLUMNS)

    rows = []
    for _, r in raw.iterrows():
        d = pd.Timestamp(r["date"])
        for feature in ("close", "volume", "amount"):
            if feature not in raw.columns:
                continue
            val = pd.to_numeric(pd.Series([r.get(feature)]), errors="coerce").iloc[0]
            if pd.isna(val):
                continue
            rows.append({
                "entity": TARGET_INDEX,
                "feature": feature,
                "observation_date": d,
                "release_date": d,
                "available_date": d,  # T日收盘后可用
                "revision_date": "",
                "value": float(val),
                "source": source,
                "data_quality": "A",
            })

    base = pd.DataFrame(rows)

    # 衍生 volatility_20d
    closes = base[base["feature"] == "close"].copy()
    closes["observation_date"] = pd.to_datetime(closes["observation_date"])
    closes = closes.sort_values("observation_date")
    closes["ret"] = closes["value"].pct_change()
    closes["vol20"] = closes["ret"].rolling(20).std() * np.sqrt(252)

    derived = []
    for _, r in closes.dropna(subset=["vol20"]).iterrows():
        d = r["observation_date"]
        derived.append({
            "entity": TARGET_INDEX,
            "feature": "volatility_20d",
            "observation_date": d,
            "release_date": d,
            "available_date": d,
            "revision_date": "",
            "value": float(r["vol20"]),
            "source": f"{source}_derived",
            "data_quality": "C",
        })

    # turnover_proxy：沿用你原 fetch_market_pit.py 的定义 amount / 1e10
    amounts = base[base["feature"] == "amount"].copy()
    for _, r in amounts.iterrows():
        d = pd.Timestamp(r["observation_date"])
        derived.append({
            "entity": TARGET_INDEX,
            "feature": "turnover_proxy",
            "observation_date": d,
            "release_date": d,
            "available_date": d,
            "revision_date": "",
            "value": float(r["value"]) / 1e10,
            "source": f"{source}_derived_proxy",
            "data_quality": "D",
        })

    if derived:
        base = pd.concat([base, pd.DataFrame(derived)], ignore_index=True)

    return _ensure_pit(base)


def fetch_930740_history(ak, start_date: str, end_date: str) -> pd.DataFrame:
    raw = _fetch_930740_csindex(ak, start_date, end_date)
    source = "CSIndex via akshare"

    if raw.empty:
        print("[INFO] CSIndex 无结果，尝试 Eastmoney 真实行情备用源")
        raw = _fetch_930740_eastmoney(ak, start_date, end_date)
        source = "Eastmoney via akshare"

    if raw.empty:
        raise RuntimeError(
            "930740 两个真实数据源均抓取失败。"
            "脚本不会回退到 demo_exchange。"
        )

    out = _market_rows_from_raw(raw, source)
    print(
        f"[OK] 930740 real market: {len(out)} PIT rows, "
        f"{out['observation_date'].min()} ~ {out['observation_date'].max()}, "
        f"source={source}"
    )
    return out


# ============================================================
# 2. 2021-2024 历史盈利快报 + revision
# ============================================================

def _quarter_ends(start_year: int, end_year: int) -> list[str]:
    quarters = []
    for y in range(start_year, end_year + 1):
        for mmdd in ("0331", "0630", "0930", "1231"):
            quarters.append(f"{y}{mmdd}")
    return quarters


def fetch_historical_earnings_kb(
    ak,
    start_year: int,
    end_year: int,
) -> pd.DataFrame:
    """
    抓历史业绩快报。
    公告日期直接作为 release_date / available_date 的基础。
    """
    parts = []

    for quarter in _quarter_ends(start_year, end_year):
        try:
            df = ak.stock_yjkb_em(date=quarter)
        except Exception as exc:
            print(f"[WARN] stock_yjkb_em({quarter}) failed: {exc}", file=sys.stderr)
            continue

        if df is None or df.empty:
            print(f"[INFO] {quarter}: no yjkb rows")
            continue

        required = {"股票代码", "公告日期", "净利润-同比增长"}
        if not required.issubset(df.columns):
            print(
                f"[WARN] {quarter}: unexpected columns={list(df.columns)}",
                file=sys.stderr,
            )
            continue

        x = df.copy()
        x["股票代码"] = x["股票代码"].astype(str).str.zfill(6)
        x["公告日期"] = pd.to_datetime(x["公告日期"], errors="coerce")
        x["净利润-同比增长"] = pd.to_numeric(
            x["净利润-同比增长"], errors="coerce"
        )

        if "营业收入-同比增长" in x.columns:
            x["营业收入-同比增长"] = pd.to_numeric(
                x["营业收入-同比增长"], errors="coerce"
            )
        else:
            x["营业收入-同比增长"] = np.nan

        # 沿用现有 V7.2 earnings fetcher 的异常值过滤区间。
        x = x[
            x["公告日期"].notna() &
            x["净利润-同比增长"].between(-200, 500, inclusive="neither")
        ].copy()

        x = x.rename(columns={
            "股票代码": "stock_code",
            "公告日期": "announce_date",
            "净利润-同比增长": "net_profit_yoy",
            "营业收入-同比增长": "revenue_yoy",
        })
        x["quarter"] = quarter
        parts.append(
            x[[
                "stock_code", "announce_date", "net_profit_yoy",
                "revenue_yoy", "quarter"
            ]]
        )

        print(
            f"[OK] {quarter}: {len(x)} rows, "
            f"announce {x['announce_date'].min()} ~ {x['announce_date'].max()}"
        )

    if not parts:
        raise RuntimeError(
            "2021-2024 历史业绩快报全部抓取失败；"
            "脚本不会生成 demo 盈利数据。"
        )

    earnings = pd.concat(parts, ignore_index=True)
    earnings = earnings.drop_duplicates(
        subset=["stock_code", "announce_date", "quarter"],
        keep="last",
    ).sort_values(["announce_date", "stock_code"])

    return earnings


def calc_revision_series(
    daily_df: pd.DataFrame,
    entity: str,
    source: str,
) -> pd.DataFrame:
    """
    与原 fetch_earnings_pit.py 一致的核心定义：
      growth_ma20 = 20日均值
      growth_ma60 = 60日均值
      revision_1m = (MA20_t - MA20_t-20) / (|MA20_t-20| + 1)
      revision_3m = (MA60_t - MA60_t-60) / (|MA60_t-60| + 1)

    注意：
    仅在“公告日”更新原始盈利状态，然后向后填充到工作日。
    不会向公告日前回填。
    """
    if daily_df.empty:
        return pd.DataFrame(columns=PIT_COLUMNS)

    x = daily_df.copy()
    x["announce_date"] = pd.to_datetime(x["announce_date"])
    x = (
        x.groupby("announce_date", as_index=False)["net_profit_yoy"]
        .median()
        .sort_values("announce_date")
        .set_index("announce_date")
    )

    idx = pd.date_range(x.index.min(), x.index.max(), freq="B")
    x = x.reindex(idx).ffill()
    x.index.name = "date"

    x["growth_ma20"] = x["net_profit_yoy"].rolling(20, min_periods=10).mean()
    x["growth_ma60"] = x["net_profit_yoy"].rolling(60, min_periods=30).mean()

    old20 = x["growth_ma20"].shift(20)
    old60 = x["growth_ma60"].shift(60)

    x["revision_1m"] = (
        (x["growth_ma20"] - old20) / (old20.abs() + 1)
    ).clip(-1, 1)
    x["revision_3m"] = (
        (x["growth_ma60"] - old60) / (old60.abs() + 1)
    ).clip(-1, 1)

    rows = []
    for d, r in x.iterrows():
        if pd.notna(r["net_profit_yoy"]):
            rows.append({
                "entity": entity,
                "feature": "earnings_growth_yoy",
                "observation_date": d,
                "release_date": d,
                "available_date": d,
                "revision_date": "",
                "value": float(r["net_profit_yoy"]),
                "source": source,
                "data_quality": "B",
            })

        if pd.notna(r["revision_1m"]):
            rows.append({
                "entity": entity,
                "feature": "earnings_revision_1m",
                "observation_date": d,
                "release_date": d,
                "available_date": d,
                "revision_date": "",
                "value": float(r["revision_1m"]),
                "source": f"{source}_derived",
                "data_quality": "C",
            })

        if pd.notna(r["revision_3m"]):
            rows.append({
                "entity": entity,
                "feature": "earnings_revision_3m",
                "observation_date": d,
                "release_date": d,
                "available_date": d,
                "revision_date": "",
                "value": float(r["revision_3m"]),
                "source": f"{source}_derived",
                "data_quality": "C",
            })

    return _ensure_pit(pd.DataFrame(rows))


# ============================================================
# 3. 可选：历史指数权重，避免幸存者偏差
# ============================================================

def load_historical_weights(weights_dir: Optional[str]) -> pd.DataFrame:
    if not weights_dir:
        return pd.DataFrame()

    root = Path(weights_dir)
    if not root.exists():
        raise FileNotFoundError(f"historical weights dir not found: {root}")

    files = sorted(root.glob("*.csv"))
    if not files:
        raise RuntimeError(f"no CSV in historical weights dir: {root}")

    parts = []
    for f in files:
        x = pd.read_csv(f, dtype={"index_code": str, "stock_code": str})
        needed = {"index_code", "stock_code", "weight", "effective_date"}
        if not needed.issubset(x.columns):
            raise ValueError(
                f"{f.name} missing columns: {sorted(needed - set(x.columns))}"
            )
        x["index_code"] = x["index_code"].astype(str).str.zfill(6)
        x["stock_code"] = x["stock_code"].astype(str).str.zfill(6)
        x["weight"] = pd.to_numeric(x["weight"], errors="coerce")
        x["effective_date"] = pd.to_datetime(x["effective_date"], errors="coerce")
        x = x.dropna(subset=["weight", "effective_date"])
        parts.append(x[list(needed)])

    return pd.concat(parts, ignore_index=True).sort_values("effective_date")


def _weighted_index_daily(
    earnings: pd.DataFrame,
    weights: pd.DataFrame,
    index_code: str,
) -> pd.DataFrame:
    """
    对每个公告日，只使用 effective_date <= 公告日的最近历史权重快照。
    """
    w_idx = weights[weights["index_code"] == index_code].copy()
    if w_idx.empty:
        return pd.DataFrame()

    snapshots = {
        d: g[["stock_code", "weight"]].copy()
        for d, g in w_idx.groupby("effective_date")
    }
    snapshot_dates = sorted(snapshots)

    out = []
    for announce_date, g in earnings.groupby("announce_date"):
        eligible = [d for d in snapshot_dates if d <= announce_date]
        if not eligible:
            continue

        eff = eligible[-1]
        w = snapshots[eff]
        m = g.merge(w, on="stock_code", how="inner")
        m = m.dropna(subset=["net_profit_yoy", "weight"])
        if m.empty or m["weight"].sum() <= 0:
            continue

        val = np.average(m["net_profit_yoy"], weights=m["weight"])
        out.append({
            "announce_date": announce_date,
            "net_profit_yoy": float(val),
            "weight_effective_date": eff,
            "constituent_count": int(len(m)),
        })

    return pd.DataFrame(out)


def build_historical_earnings_pit(
    earnings: pd.DataFrame,
    historical_weights: pd.DataFrame,
) -> pd.DataFrame:
    parts = []

    # 全市场序列：真实公告数据，PIT-safe。
    cn = (
        earnings.groupby("announce_date", as_index=False)
        .agg(net_profit_yoy=("net_profit_yoy", "median"))
    )
    parts.append(
        calc_revision_series(
            cn,
            entity="CN",
            source="yjkb_akshare_historical_market_median",
        )
    )

    # 指数级历史盈利：仅在用户提供历史权重时生成。
    if historical_weights.empty:
        print(
            "[WARN] 未提供历史指数权重："
            "不会使用当前成分股权重重构 2021-2024 指数盈利，"
            "以避免 survivorship / constituent look-ahead bias。",
            file=sys.stderr,
        )
    else:
        for code in UNIVERSE:
            idx_daily = _weighted_index_daily(
                earnings,
                historical_weights,
                code,
            )
            if idx_daily.empty:
                print(f"[WARN] {code}: no PIT-safe historical weight match")
                continue

            parts.append(
                calc_revision_series(
                    idx_daily[["announce_date", "net_profit_yoy"]],
                    entity=code,
                    source=f"yjkb_akshare_historical_weights_{code}",
                )
            )
            print(
                f"[OK] {code}: historical earnings aggregation "
                f"{len(idx_daily)} announcement dates"
            )

    out = pd.concat(parts, ignore_index=True)
    return _ensure_pit(out)


# ============================================================
# 4. 合并 / 去重 / 审计
# ============================================================

def merge_replace_market(
    existing_path: Path,
    new_930740: pd.DataFrame,
    out_path: Path,
) -> pd.DataFrame:
    if existing_path.exists():
        old = pd.read_csv(existing_path, dtype={"entity": str})
        old["entity"] = old["entity"].astype(str).str.zfill(6)

        # 删除所有旧 930740，尤其 demo_exchange。
        old = old[old["entity"] != TARGET_INDEX].copy()
        merged = pd.concat([old, new_930740], ignore_index=True)
    else:
        merged = new_930740.copy()

    merged = _ensure_pit(merged)
    merged = merged.drop_duplicates(
        subset=["entity", "feature", "observation_date", "available_date"],
        keep="last",
    ).sort_values(["entity", "feature", "observation_date"])

    out_path.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(out_path, index=False)
    return merged


def merge_earnings(
    existing_path: Path,
    new_hist: pd.DataFrame,
    out_path: Path,
) -> pd.DataFrame:
    parts = [new_hist]
    if existing_path.exists():
        old = pd.read_csv(existing_path, dtype={"entity": str})
        parts.append(old)

    merged = pd.concat(parts, ignore_index=True)
    merged = _ensure_pit(merged)

    # 同一个 PIT key：保留 source 非 demo 的优先记录。
    merged["_is_demo"] = merged["source"].astype(str).str.contains(
        "demo", case=False, na=False
    )
    merged = merged.sort_values(
        ["entity", "feature", "observation_date", "available_date", "_is_demo"]
    )
    merged = merged.drop_duplicates(
        subset=["entity", "feature", "observation_date", "available_date"],
        keep="first",
    ).drop(columns="_is_demo")

    merged = merged.sort_values(["entity", "feature", "observation_date"])
    out_path.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(out_path, index=False)
    return merged


def pit_audit(df: pd.DataFrame, name: str) -> dict:
    x = df.copy()
    for c in ("observation_date", "release_date", "available_date"):
        x[c] = pd.to_datetime(x[c], errors="coerce")

    invalid_release = int(
        (x["available_date"] < x["release_date"]).fillna(False).sum()
    )
    invalid_obs = int(
        (x["available_date"] < x["observation_date"]).fillna(False).sum()
    )
    demo_rows = int(
        x["source"].astype(str).str.contains("demo", case=False, na=False).sum()
    )

    return {
        "dataset": name,
        "rows": int(len(x)),
        "entities": int(x["entity"].nunique()),
        "features": int(x["feature"].nunique()),
        "min_observation_date": str(x["observation_date"].min().date())
            if len(x) else None,
        "max_observation_date": str(x["observation_date"].max().date())
            if len(x) else None,
        "available_before_release_rows": invalid_release,
        "available_before_observation_rows": invalid_obs,
        "demo_rows": demo_rows,
    }


def coverage_report(
    market_930740: pd.DataFrame,
    earnings_hist: pd.DataFrame,
    start_year: int,
    end_year: int,
) -> dict:
    report = {
        "market_930740": pit_audit(market_930740, "930740_market"),
        "earnings_history": pit_audit(earnings_hist, "earnings_history"),
        "earnings_by_entity": {},
    }

    x = earnings_hist.copy()
    x["observation_date"] = pd.to_datetime(x["observation_date"])

    for entity, g in x.groupby("entity"):
        entity_report = {}
        for feature, h in g.groupby("feature"):
            entity_report[feature] = {
                "rows": int(len(h)),
                "start": str(h["observation_date"].min().date()),
                "end": str(h["observation_date"].max().date()),
            }
        report["earnings_by_entity"][str(entity)] = entity_report

    # 年度覆盖提示
    annual = []
    for y in range(start_year, end_year + 1):
        g = x[x["observation_date"].dt.year == y]
        annual.append({
            "year": y,
            "rows": int(len(g)),
            "entities": int(g["entity"].nunique()) if len(g) else 0,
        })
    report["earnings_annual_coverage"] = annual
    return report


def rebuild_unified_pit(pit_dir: Path) -> Optional[Path]:
    names = [
        "macro_pit.csv",
        "market_pit.csv",
        "valuation_pit.csv",
        "flow_pit.csv",
        "policy_pit.csv",
        "earnings_pit.csv",
    ]

    parts = []
    for name in names:
        p = pit_dir / name
        if p.exists():
            parts.append(pd.read_csv(p, dtype={"entity": str}))

    if not parts:
        return None

    unified = pd.concat(parts, ignore_index=True)
    unified = _ensure_pit(unified)
    unified = unified.drop_duplicates(
        subset=["entity", "feature", "observation_date", "available_date", "source"],
        keep="last",
    )
    out = pit_dir / "unified_pit.csv"
    unified.to_csv(out, index=False)
    print(f"[OK] Unified PIT rebuilt: {out} ({len(unified)} rows)")
    return out


# ============================================================
# 5. CLI
# ============================================================

def main():
    p = argparse.ArgumentParser(
        description="V7.3: fetch missing 930740 market + 2021-2024 earnings history"
    )
    p.add_argument("--market-start", default="20200101")
    p.add_argument("--market-end", default="20260630")
    p.add_argument("--earnings-start-year", type=int, default=2021)
    p.add_argument("--earnings-end-year", type=int, default=2024)

    p.add_argument(
        "--historical-weights-dir",
        default=None,
        help="可选。历史指数权重CSV目录；未提供时不构造指数级历史盈利。",
    )

    p.add_argument(
        "--market-existing",
        default=str(PIT_DIR / "market_pit.csv"),
    )
    p.add_argument(
        "--earnings-existing",
        default=str(PIT_DIR / "earnings_pit.csv"),
    )
    p.add_argument(
        "--market-out",
        default=str(PIT_DIR / "market_pit.csv"),
    )
    p.add_argument(
        "--earnings-out",
        default=str(PIT_DIR / "earnings_pit.csv"),
    )
    p.add_argument(
        "--raw-earnings-out",
        default=str(PIT_DIR / "earnings_yjkb_history_raw.csv"),
    )
    p.add_argument(
        "--report-out",
        default=str(PIT_DIR / "v7_3_missing_history_coverage.json"),
    )

    p.add_argument(
        "--no-merge",
        action="store_true",
        help="只生成缺失历史文件，不覆盖/合并现有 market_pit 和 earnings_pit。",
    )
    p.add_argument(
        "--no-rebuild-unified",
        action="store_true",
        help="合并后不重建 unified_pit.csv。",
    )

    args = p.parse_args()

    ak = _try_akshare()

    # ---------- 930740 ----------
    market_930740 = fetch_930740_history(
        ak,
        start_date=args.market_start,
        end_date=args.market_end,
    )

    standalone_market = PIT_DIR / "market_930740_real_history.csv"
    market_930740.to_csv(standalone_market, index=False)
    print(f"[OK] standalone 930740 -> {standalone_market}")

    # ---------- Earnings ----------
    raw_earnings = fetch_historical_earnings_kb(
        ak,
        start_year=args.earnings_start_year,
        end_year=args.earnings_end_year,
    )

    raw_path = Path(args.raw_earnings_out)
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    raw_earnings.to_csv(raw_path, index=False)
    print(f"[OK] raw historical yjkb -> {raw_path} ({len(raw_earnings)} rows)")

    hist_weights = load_historical_weights(args.historical_weights_dir)
    earnings_hist = build_historical_earnings_pit(raw_earnings, hist_weights)

    standalone_earnings = PIT_DIR / "earnings_pit_history_2021_2024.csv"
    earnings_hist.to_csv(standalone_earnings, index=False)
    print(f"[OK] standalone historical earnings PIT -> {standalone_earnings}")

    # ---------- Audit ----------
    report = coverage_report(
        market_930740,
        earnings_hist,
        args.earnings_start_year,
        args.earnings_end_year,
    )

    report_path = Path(args.report_out)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"[OK] coverage report -> {report_path}")

    print("\n=== PIT AUDIT ===")
    print(json.dumps(report, ensure_ascii=False, indent=2))

    bad = (
        report["market_930740"]["available_before_release_rows"] > 0
        or report["earnings_history"]["available_before_release_rows"] > 0
    )
    if bad:
        raise SystemExit("[FAIL] PIT audit found available_date < release_date")

    # ---------- Merge ----------
    if not args.no_merge:
        market_merged = merge_replace_market(
            Path(args.market_existing),
            market_930740,
            Path(args.market_out),
        )
        print(
            f"[OK] market merged -> {args.market_out}; "
            f"930740 demo rows remaining="
            f"{len(market_merged[(market_merged['entity'] == TARGET_INDEX) & market_merged['source'].str.contains('demo', case=False, na=False)])}"
        )

        earnings_merged = merge_earnings(
            Path(args.earnings_existing),
            earnings_hist,
            Path(args.earnings_out),
        )
        print(f"[OK] earnings merged -> {args.earnings_out} ({len(earnings_merged)} rows)")

        if not args.no_rebuild_unified:
            rebuild_unified_pit(PIT_DIR)

    print("\n[DONE] V7.3 missing-history fetch completed.")
    if hist_weights.empty:
        print(
            "[NOTE] 当前仅生成了 PIT-safe 的全市场历史盈利修正。"
            "若要给六个指数生成 2021-2024 各自的盈利修正，"
            "请提供历史指数成分/权重CSV，并通过 --historical-weights-dir 指定。"
        )


if __name__ == "__main__":
    main()
