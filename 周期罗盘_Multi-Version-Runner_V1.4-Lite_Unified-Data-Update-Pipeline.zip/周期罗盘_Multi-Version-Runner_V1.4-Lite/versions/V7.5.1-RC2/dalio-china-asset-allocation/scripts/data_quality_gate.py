#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, hashlib
from pathlib import Path
import pandas as pd

REQUIRED_COMPONENTS = [
    'macro_pit.csv','market_pit.csv','valuation_pit.csv','flow_pit.csv','policy_pit.csv','earnings_pit.csv'
]
REQUIRED_COLUMNS = {'observation_date','available_date','feature','entity','value'}
MIN_UNIFIED_ROWS = 100000
MIN_FEATURES = 10
MIN_ENTITIES = 5

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--pit-dir', default='data/pit')
    ap.add_argument('--output', default='outputs/v751_rc2/data_quality_summary.json')
    args=ap.parse_args()
    pit=Path(args.pit_dir); out=Path(args.output); out.parent.mkdir(parents=True, exist_ok=True)
    checks=[]
    def add(name, ok, detail): checks.append({'check':name,'pass':bool(ok),'detail':detail})

    for name in REQUIRED_COMPONENTS:
        p=pit/name
        add(f'component_exists:{name}', p.exists() and p.stat().st_size>0, f'{p} exists={p.exists()} size={p.stat().st_size if p.exists() else 0}')

    u=pit/'unified_pit.csv'
    if not u.exists():
        add('unified_exists',False,str(u)); summary={'grade':'FAIL','checks':checks}; out.write_text(json.dumps(summary,indent=2),encoding='utf-8'); raise SystemExit(2)
    d=pd.read_csv(u,low_memory=False)
    add('required_columns', REQUIRED_COLUMNS.issubset(d.columns), f'columns={list(d.columns)}')
    add('minimum_rows', len(d)>=MIN_UNIFIED_ROWS, f'rows={len(d)} threshold={MIN_UNIFIED_ROWS}')
    add('minimum_features', d['feature'].nunique()>=MIN_FEATURES, f"features={d['feature'].nunique()} threshold={MIN_FEATURES}")
    add('minimum_entities', d['entity'].astype(str).nunique()>=MIN_ENTITIES, f"entities={d['entity'].astype(str).nunique()} threshold={MIN_ENTITIES}")
    obs=pd.to_datetime(d['observation_date'],errors='coerce'); av=pd.to_datetime(d['available_date'],errors='coerce'); val=pd.to_numeric(d['value'],errors='coerce')
    add('valid_dates', obs.notna().all() and av.notna().all(), f'invalid_observation={int(obs.isna().sum())}, invalid_available={int(av.isna().sum())}')
    add('no_pit_order_violation', bool((av>=obs).all()), f'available_before_observation={int((av<obs).sum())}')
    add('numeric_value_coverage', float(val.notna().mean())>=0.98, f'numeric_coverage={val.notna().mean():.4%} threshold=98%; missing values are not imputed')
    dup=int(d.duplicated(['feature','entity','observation_date','available_date']).sum())
    add('duplicate_rate', dup/max(len(d),1)<=0.01, f'duplicates={dup}, rate={dup/max(len(d),1):.4%}')
    checksums={name:sha256(pit/name) for name in REQUIRED_COMPONENTS if (pit/name).exists()}
    checksums['unified_pit.csv']=sha256(u)
    passed=sum(x['pass'] for x in checks); grade='PASS' if passed==len(checks) else 'FAIL'
    summary={'version':'V7.5.1-RC2 data quality gate','grade':grade,'checks_passed':passed,'checks_total':len(checks),'rows':len(d),'features':int(d['feature'].nunique()),'entities':int(d['entity'].astype(str).nunique()),'min_observation_date':str(obs.min().date()),'max_observation_date':str(obs.max().date()),'max_available_date':str(av.max().date()),'checksums':checksums,'checks':checks}
    out.write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    raise SystemExit(0 if grade=='PASS' else 2)
if __name__=='__main__': main()
