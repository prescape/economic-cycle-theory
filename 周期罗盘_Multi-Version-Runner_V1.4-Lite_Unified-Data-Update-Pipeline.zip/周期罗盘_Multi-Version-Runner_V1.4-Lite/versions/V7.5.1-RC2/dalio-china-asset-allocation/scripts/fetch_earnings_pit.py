#!/usr/bin/env python3
"""
fetch_earnings_pit.py — Dalio China V7.2 盈利修正数据采集（Point-in-Time）

采集项：
- earnings_growth_yoy: 净利润同比增长（中位数）
- earnings_revision_1m: 1个月盈利修正趋势
- earnings_revision_3m: 3个月盈利修正趋势

数据源：
- 业绩快报: akshare stock_yjkb_em（个股级别，含净利润同比增长）
- 指数成分股权重: akshare index_stock_cons_weight_csindex

PIT 规则：业绩快报公告日期 = release_date = available_date
"""
import argparse
import sys
from pathlib import Path

import pandas as pd
import numpy as np

OUT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"
OUT_DIR.mkdir(parents=True, exist_ok=True)

UNIVERSE = {
    "000300": {"name": "沪深300"},
    "000852": {"name": "中证1000"},
    "399006": {"name": "创业板指"},
    "000688": {"name": "科创50"},
    "000016": {"name": "上证50"},
    "930740": {"name": "300红利低波"},
}

# 业绩快报季度列表（从近到远）
QUARTERS = ["20241231", "20240930", "20240630", "20240331"]


def _add_pit_meta(df: pd.DataFrame) -> pd.DataFrame:
    required = ["entity", "feature", "observation_date", "release_date",
                "available_date", "value", "source", "data_quality"]
    for c in required:
        if c not in df.columns:
            raise ValueError(f"PIT column missing: {c}")
    df["observation_date"] = pd.to_datetime(df["observation_date"]).dt.strftime("%Y-%m-%d")
    df["release_date"] = pd.to_datetime(df["release_date"]).dt.strftime("%Y-%m-%d")
    df["available_date"] = pd.to_datetime(df["available_date"]).dt.strftime("%Y-%m-%d")
    df["revision_date"] = ""
    return df[["entity", "feature", "observation_date", "release_date",
               "available_date", "revision_date", "value", "source", "data_quality"]]


def _try_akshare():
    try:
        import akshare as ak
        return ak
    except ImportError:
        return None


def fetch_earnings_kb(ak) -> pd.DataFrame:
    """获取业绩快报（个股级别）。"""
    rows = []
    if ak is None:
        return pd.DataFrame(rows)
    
    for quarter in QUARTERS:
        try:
            df = ak.stock_yjkb_em(date=quarter)
            df["公告日期"] = pd.to_datetime(df["公告日期"])
            df["净利润-同比增长"] = pd.to_numeric(df["净利润-同比增长"], errors="coerce")
            df["营业收入-同比增长"] = pd.to_numeric(df["营业收入-同比增长"], errors="coerce")
            # 过滤异常值
            df = df[(df["净利润-同比增长"] > -200) & (df["净利润-同比增长"] < 500)]
            for _, r in df.iterrows():
                rows.append({
                    "stock_code": str(r["股票代码"]).zfill(6),
                    "announce_date": r["公告日期"],
                    "net_profit_yoy": r["净利润-同比增长"],
                    "revenue_yoy": r["营业收入-同比增长"],
                    "quarter": quarter,
                })
        except Exception as e:
            print(f"[WARN] stock_yjkb_em {quarter} failed: {e}", file=sys.stderr)
    
    return pd.DataFrame(rows)


def fetch_index_weights(ak, code: str) -> pd.DataFrame:
    """获取指数成分股权重。"""
    if ak is None:
        return pd.DataFrame()
    try:
        df = ak.index_stock_cons_weight_csindex(symbol=code)
        df["成分券代码"] = df["成分券代码"].astype(str).str.zfill(6)
        df["权重"] = pd.to_numeric(df["权重"], errors="coerce")
        return df[["成分券代码", "权重"]].rename(columns={"成分券代码": "stock_code", "权重": "weight"})
    except Exception as e:
        print(f"[WARN] index weights {code} failed: {e}", file=sys.stderr)
        return pd.DataFrame()


def calc_earnings_by_index(earnings_df: pd.DataFrame, weights_df: pd.DataFrame) -> pd.DataFrame:
    """按指数权重加权计算盈利增长。"""
    if weights_df.empty or earnings_df.empty:
        return pd.DataFrame()
    
    merged = earnings_df.merge(weights_df, on="stock_code", how="inner")
    if merged.empty:
        return pd.DataFrame()
    
    # 按公告日期加权聚合
    daily = []
    for date, g in merged.groupby("announce_date"):
        # 加权中位数（简单用加权均值）
        weighted_growth = np.average(g["net_profit_yoy"].dropna(), weights=g["weight"].dropna())
        daily.append({
            "announce_date": date,
            "net_profit_yoy": weighted_growth,
        })
    return pd.DataFrame(daily)


def calc_revision_series(daily_df: pd.DataFrame, entity: str, source: str) -> pd.DataFrame:
    """从日度盈利增长序列计算 revision_1m 和 revision_3m。"""
    if daily_df.empty:
        return pd.DataFrame()
    
    daily_df = daily_df.sort_values("announce_date").set_index("announce_date")
    # 重采样到交易日（向前填充）
    idx = pd.date_range(daily_df.index.min(), daily_df.index.max(), freq="B")
    daily_df = daily_df.reindex(idx).ffill()
    daily_df.index.name = "date"
    
    rows = []
    for d, g in daily_df.iterrows():
        val = g["net_profit_yoy"]
        if pd.isna(val):
            continue
        rows.append({
            "entity": entity, "feature": "earnings_growth_yoy",
            "observation_date": d, "release_date": d, "available_date": d,
            "value": round(val, 4),
            "source": source, "data_quality": "B"
        })
    
    # 计算 revision：增速的 20日/60日变化
    daily_df["growth_ma20"] = daily_df["net_profit_yoy"].rolling(20, min_periods=10).mean()
    daily_df["growth_ma60"] = daily_df["net_profit_yoy"].rolling(60, min_periods=30).mean()
    
    # revision_1m = (当前20日MA - 20日前20日MA) / |20日前20日MA|
    daily_df["revision_1m"] = (daily_df["growth_ma20"] - daily_df["growth_ma20"].shift(20)) / (daily_df["growth_ma20"].shift(20).abs() + 1)
    # revision_3m = (当前60日MA - 60日前60日MA) / |60日前60日MA|
    daily_df["revision_3m"] = (daily_df["growth_ma60"] - daily_df["growth_ma60"].shift(60)) / (daily_df["growth_ma60"].shift(60).abs() + 1)
    
    for d, g in daily_df.iterrows():
        if not pd.isna(g["revision_1m"]):
            rows.append({
                "entity": entity, "feature": "earnings_revision_1m",
                "observation_date": d, "release_date": d, "available_date": d,
                "value": round(np.clip(g["revision_1m"], -1, 1), 6),
                "source": f"{source}_derived", "data_quality": "C"
            })
        if not pd.isna(g["revision_3m"]):
            rows.append({
                "entity": entity, "feature": "earnings_revision_3m",
                "observation_date": d, "release_date": d, "available_date": d,
                "value": round(np.clip(g["revision_3m"], -1, 1), 6),
                "source": f"{source}_derived", "data_quality": "C"
            })
    
    return pd.DataFrame(rows)


def _demo_earnings(start="2024-01-01", days=400) -> pd.DataFrame:
    """生成示例盈利数据。"""
    rows = []
    import random
    random.seed(2024)
    growth = 5.0
    for i in range(days):
        d = pd.Timestamp(start) + pd.Timedelta(days=i)
        if d.weekday() >= 5:
            continue
        growth = growth + random.gauss(0, 0.5) + (5 - growth) * 0.05
        rev_1m = random.gauss(0, 0.1)
        rev_3m = random.gauss(0, 0.15)
        rows.append({"entity": "CN", "feature": "earnings_growth_yoy",
                     "observation_date": d, "release_date": d, "available_date": d,
                     "value": round(growth, 4), "source": "derived_demo", "data_quality": "C"})
        rows.append({"entity": "CN", "feature": "earnings_revision_1m",
                     "observation_date": d, "release_date": d, "available_date": d,
                     "value": round(rev_1m, 6), "source": "derived_demo", "data_quality": "C"})
        rows.append({"entity": "CN", "feature": "earnings_revision_3m",
                     "observation_date": d, "release_date": d, "available_date": d,
                     "value": round(rev_3m, 6), "source": "derived_demo", "data_quality": "C"})
        for code in UNIVERSE:
            rows.append({"entity": code, "feature": "earnings_growth_yoy",
                         "observation_date": d, "release_date": d, "available_date": d,
                         "value": round(growth + random.gauss(0, 2), 4),
                         "source": "derived_demo", "data_quality": "C"})
    return pd.DataFrame(rows)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default=str(OUT_DIR / "earnings_pit.csv"))
    p.add_argument("--demo", action="store_true")
    args = p.parse_args()

    ak = None if args.demo else _try_akshare()
    parts = []

    # 1. 获取业绩快报
    earnings = fetch_earnings_kb(ak)
    if not earnings.empty:
        print(f"[INFO] Earnings KB fetched: {len(earnings)} rows, date range {earnings['announce_date'].min()} ~ {earnings['announce_date'].max()}")
        
        # 2. 全市场聚合
        cn_daily = earnings.groupby("announce_date").agg(
            net_profit_yoy=("net_profit_yoy", "median")
        ).reset_index()
        parts.append(calc_revision_series(cn_daily, "CN", "yjkb_akshare"))
        
        # 3. 各指数加权聚合
        for code in UNIVERSE:
            weights = fetch_index_weights(ak, code)
            if not weights.empty:
                idx_daily = calc_earnings_by_index(earnings, weights)
                if not idx_daily.empty:
                    parts.append(calc_revision_series(idx_daily, code, f"yjkb_akshare_{code}"))
                    print(f"[INFO] {code} earnings: {len(idx_daily)} daily points")
    
    if not parts:
        print("[INFO] 使用示例数据")
        parts.append(_demo_earnings())

    df = pd.concat(parts, ignore_index=True)
    if df.empty:
        print("[WARN] No earnings data generated")
        return
    
    df = _add_pit_meta(df)
    df.to_csv(args.out, index=False)
    print(f"[OK] Earnings PIT → {args.out} ({len(df)} rows)")
    
    # 最新数据摘要
    latest = df.copy()
    latest["observation_date"] = pd.to_datetime(latest["observation_date"])
    max_date = latest["observation_date"].max()
    print(f"\nLatest data: {max_date.strftime('%Y-%m-%d')}")
    summary = latest[latest["observation_date"] == max_date][["entity", "feature", "value", "source"]]
    if not summary.empty:
        print("\nLatest records:")
        for _, r in summary.iterrows():
            print(f"  {r['entity']:>8s} {r['feature']:25s}: {r['value']:>12.4f}  ({r['source']})")


if __name__ == "__main__":
    main()
