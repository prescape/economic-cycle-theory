#!/usr/bin/env python3
"""
walkforward_v72_ab2.py — 精细调优：测试 3mo/4mo/6mo 动量窗口
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import numpy as np
import yaml

PIT_DIR = Path(__file__).resolve().parents[1] / "data" / "pit"
CONFIG_PATH = Path(__file__).resolve().parents[1] / ".." / "dalio-china-v7-2-frozen" / "config" / "freeze.yaml"
WF_PATH = Path(__file__).resolve().parents[1] / "data" / "walkforward_v72.csv"

INDEX_MAP = {
    "000300": "沪深300", "000852": "中证1000", "399006": "创业板指",
    "000688": "科创50", "000016": "上证50", "930740": "300红利低波",
}
ENTITY_INT_MAP = {300: "000300", 852: "000852", 399006: "399006", 688: "000688", 16: "000016", 930740: "930740"}

def load_cfg():
    with open(CONFIG_PATH) as f:
        return yaml.safe_load(f)

def load_ts(cutoff):
    ts = {}
    for name in ["macro", "market", "valuation", "flow", "policy", "earnings"]:
        f = PIT_DIR / f"{name}_pit.csv"
        if not f.exists(): continue
        df = pd.read_csv(f)
        df["available_date"] = pd.to_datetime(df["available_date"])
        df = df[df["available_date"] <= cutoff].copy()
        if name in ("market", "valuation"):
            df["entity"] = df["entity"].map(ENTITY_INT_MAP)
        for (e, feat), g in df.groupby(["entity", "feature"]):
            ts[(e, feat)] = g.sort_values("available_date")[["available_date", "value"]].reset_index(drop=True)
    return ts

def latest(ts, key):
    s = ts.get(key)
    return s["value"].iloc[-1] if s is not None and not s.empty else None

def history(ts, key, months):
    s = ts.get(key)
    if s is None or s.empty: return None
    cutoff = list(ts.values())[0]["available_date"].iloc[-1] - pd.DateOffset(months=months)
    hist = s[s["available_date"] >= cutoff]["value"].dropna().values
    return hist if len(hist) >= 3 else None

def pct(value, hist):
    if hist is None or len(hist) == 0: return 0.5
    return np.clip(np.searchsorted(np.sort(hist), value) / len(hist), 0.05, 0.95)

def calc_regime(ts, cfg, tw):
    w = cfg["weights"]["macro_regime"]
    gdp = latest(ts, ("CN", "GDP_yoy")) or 5.0
    pmi = latest(ts, ("CN", "PMI")) or 50.0
    m2 = latest(ts, ("CN", "M2_yoy")) or 8.0
    cpi = latest(ts, ("CN", "CPI_yoy")) or 2.0
    ppi = latest(ts, ("CN", "PPI_yoy")) or 0.0
    growth = pct(gdp, history(ts, ("CN", "GDP_yoy"), tw)) * 0.5 + \
             pct(pmi, history(ts, ("CN", "PMI"), tw)) * 0.5
    liquidity = pct(m2, history(ts, ("CN", "M2_yoy"), tw))
    inflation = (pct(abs(cpi - 2), history(ts, ("CN", "CPI_yoy"), tw)) +
                 pct(abs(ppi), history(ts, ("CN", "PPI_yoy"), tw))) / 2
    score = growth * w["growth"] + 0.5 * w["credit"] + liquidity * w["liquidity"] + \
            0.5 * w["policy"] + inflation * w["inflation"]
    regime = "Risk-On" if score >= 0.55 else ("Risk-Off" if score <= 0.35 else "Neutral")
    return {"score": round(score, 4), "regime": regime}

def calc_alpha(ts, cfg, code, tw, mw, mom_acceleration=False):
    aw = cfg["weights"]["alpha"]
    f = {}

    er = latest(ts, (code, "earnings_growth_yoy")) or latest(ts, (code, "earnings_revision_1m")) or latest(ts, (code, "earnings_revision_3m"))
    f["earnings"] = pct(er, history(ts, ("CN", "earnings_growth_yoy"), tw)) if er is not None else 0.5

    pe = latest(ts, (code, "PE_TTM"))
    f["valuation"] = 1 - pct(pe, history(ts, (code, "PE_TTM"), tw)) if pe is not None else 0.5

    flow = latest(ts, (code, "fund_flow"))
    f["flow"] = pct(flow, history(ts, (code, "fund_flow"), tw)) if flow is not None else 0.5

    close = latest(ts, (code, "close"))
    if close is not None:
        ch = history(ts, (code, "close"), months=mw)
        if ch is not None and len(ch) >= 2:
            mom = close / ch[0] - 1
            s = ts.get((code, "close"))
            rets = []
            if s is not None and len(s) >= 7:
                vals = s["value"].values
                for i in range(1, len(vals)): rets.append(vals[i] / vals[i - 1] - 1)
            f["momentum"] = pct(mom, np.array(rets) if rets else None)

            # 动量加速度：近1月 vs 近mw月，捕捉趋势加速
            if mom_acceleration and s is not None and len(s) >= 4:
                v = s["value"].values
                mom_1m = v[-1] / v[-2] - 1 if v[-2] != 0 else 0
                mom_nm = v[-1] / v[-min(len(v), mw*4)] - 1 if v[-min(len(v), mw*4)] != 0 else 0
                accel = mom_1m - (mom_nm / max(mw, 1))
                if accel > 0.02:  # 加速上涨
                    f["momentum"] = min(f["momentum"] * 1.15, 0.95)
                elif accel < -0.02:  # 加速下跌
                    f["momentum"] = max(f["momentum"] * 0.85, 0.05)
        else:
            f["momentum"] = 0.5
    else:
        f["momentum"] = 0.5

    f["crowding"] = 0.5
    pol = latest(ts, ("CN", "policy_theme"))
    f["policy"] = np.clip(pol, 0, 1) if pol is not None else 0.5
    f["macro_style"] = 0.5

    score = (f["earnings"] * aw["earnings"]["weight"] + f["valuation"] * aw["valuation"]["weight"] +
             f["flow"] * aw["flow"]["weight"] + f["momentum"] * aw["momentum"]["weight"] +
             f["crowding"] * aw["crowding"]["weight"] + f["policy"] * aw["policy"]["weight"] +
             f["macro_style"] * aw["macro_style"]["weight"])
    return round(score, 4), f

def softmax(scores, t=0.5):
    vals = np.array(list(scores.values()))
    exp = np.exp((vals - vals.max()) / t)
    return {k: round(v, 4) for k, v in zip(scores.keys(), exp / exp.sum())}

def predict_month(ts, cfg, tw, mw, mom_acc):
    regime = calc_regime(ts, cfg, tw)
    scores = {}
    for code, name in INDEX_MAP.items():
        s, _ = calc_alpha(ts, cfg, code, tw, mw, mom_acc)
        scores[name] = s
    weights = softmax(scores)
    ranked = sorted(weights.items(), key=lambda x: x[1], reverse=True)
    return regime, weights, ranked[0][0]

def main():
    print("=" * 80)
    print("V7.2-FROZEN  精细调优对比 (动量窗口 3mo/4mo/6mo)")
    print("=" * 80)

    cfg = load_cfg()
    wf = pd.read_csv(WF_PATH)
    wf["date"] = pd.to_datetime(wf["date"])

    # 验证 2024 年后 + 重点看 2025-2026 风格切换期
    test_periods = wf[wf["date"] >= "2024-01-01"]["date"].tolist()

    configs = []
    for mw in [3, 4, 6]:
        for tw in [24, 36]:
            configs.append((f"动量{mw}mo/训练{tw}mo", tw, mw, False))
    # 加一组带加速度的
    configs.append(("动量3mo/训练24mo+加速度", 24, 3, True))
    configs.append(("动量4mo/训练36mo+加速度", 36, 4, True))

    results = {}
    for label, _, _, _ in configs:
        results[label] = {"mae": [], "rmse": [], "top1_acc": [], "regime_acc": [], "rank_corr": []}

    for target_date in test_periods:
        cutoff = target_date - pd.DateOffset(months=1)
        ts = load_ts(cutoff)
        if not ts: continue

        actual = wf[wf["date"] == target_date].iloc[0]
        actual_weights = {name: actual[f"w_{name}"] for name in INDEX_MAP.values()}
        actual_top1 = actual["top1"]
        actual_regime = actual["regime"]
        actual_scores = {name: actual[f"s_{name}"] for name in INDEX_MAP.values()}
        actual_rank = {k: i for i, (k, _) in enumerate(sorted(actual_scores.items(), key=lambda x: x[1], reverse=True))}

        for label, tw, mw, mom_acc in configs:
            regime_pred, weights_pred, top1_pred = predict_month(ts, cfg, tw, mw, mom_acc)

            mae = sum(abs(weights_pred[n] - actual_weights[n]) for n in INDEX_MAP.values()) / len(INDEX_MAP)
            rmse = np.sqrt(sum((weights_pred[n] - actual_weights[n]) ** 2 for n in INDEX_MAP.values()) / len(INDEX_MAP))
            pred_scores = {n: weights_pred[n] for n in INDEX_MAP.values()}
            pred_rank = {k: i for i, (k, _) in enumerate(sorted(pred_scores.items(), key=lambda x: x[1], reverse=True))}
            rank_corr = np.corrcoef([pred_rank[n] for n in INDEX_MAP.values()],
                                    [actual_rank[n] for n in INDEX_MAP.values()])[0, 1]

            results[label]["mae"].append(mae)
            results[label]["rmse"].append(rmse)
            results[label]["top1_acc"].append(1 if top1_pred == actual_top1 else 0)
            results[label]["regime_acc"].append(1 if regime_pred["regime"] == actual_regime else 0)
            results[label]["rank_corr"].append(rank_corr)

    print(f"\n验证月份数: {len(test_periods)}")
    print(f"验证区间: {test_periods[0].date()} ~ {test_periods[-1].date()}")
    print("\n" + "=" * 80)
    print("【精细调优结果】")
    print("=" * 80)

    table = []
    for label, r in results.items():
        table.append({
            "方案": label,
            "MAE": np.mean(r["mae"]),
            "RMSE": np.mean(r["rmse"]),
            "RankCorr": np.mean(r["rank_corr"]),
            "Top1%": np.mean(r["top1_acc"]),
            "Regime%": np.mean(r["regime_acc"]),
        })

    df = pd.DataFrame(table).sort_values("MAE")
    print("\n" + df.to_string(index=False))

    best = df.iloc[0]
    print(f"\n{'='*80}")
    print(f"【最优方案】: {best['方案']}")
    print(f"  MAE: {best['MAE']:.2%} | RMSE: {best['RMSE']:.2%} | RankCorr: {best['RankCorr']:.3f} | Top1: {best['Top1%']:.1%}")
    print("=" * 80)


if __name__ == "__main__":
    main()
