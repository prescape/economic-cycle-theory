"""周期罗盘 V7.28.5 — Asymmetric Alpha Transition Shadow

Research-only. No sizing authority over V7.28.4.

Variant A (Gate-2Confirm):
- Eligible when quadrant == "Reflation" OR regime == "Risk-On".
- Entry requires eligibility on 2 consecutive semi-monthly nodes.
- Any ineligible node exits the Breadth Tilt immediately.

Variant B (Pair-2Confirm):
- Same frozen gate.
- Entry requires the same Breadth top/bottom asset pair to persist
  for 2 consecutive eligible nodes.
- Gate failure or pair change exits immediately.
- New pair requires fresh 2-node confirmation.

Frozen:
- Breadth = Close / MA120 - 1
- Tilt = 10% of risky allocation
- 10bps one-way transaction cost
"""
def gate_eligible(quadrant, regime):
    return quadrant == "Reflation" or regime == "Risk-On"

def gate2confirm(current_eligible, previous_eligible):
    return bool(current_eligible and previous_eligible)

def pair2confirm(current_eligible, previous_eligible,
                 current_top, current_bottom, previous_top, previous_bottom):
    return bool(
        current_eligible and previous_eligible
        and current_top == previous_top
        and current_bottom == previous_bottom
    )
