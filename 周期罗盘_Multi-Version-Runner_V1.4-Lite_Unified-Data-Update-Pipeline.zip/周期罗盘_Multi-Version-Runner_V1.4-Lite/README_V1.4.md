# 周期罗盘 Multi-Version Runner V1.4 Lite
## Unified Data Update Pipeline

V1.4 只升级数据调度层，不修改 V7.5.1 / V7.28.4 / V7.28.5 策略参数。

### 一键运行
```bash
python update_data.py
```

### 流水线
Fetch PIT
→ Source Repair
→ Quarantine demo/example
→ Freshness + Source Quality Gate
→ Sync shared PIT
→ 自动识别五指数共同最新交易日
→ build_current_factor_panel.py
→ V7.5.1 / V7.28.4 / V7.28.5
→ ALL_3_VERSIONS_OK
→ FORMAL_ADVICE_AVAILABLE

### V1.4 新增规则
- ROOT 使用相对安装目录，不再写死 OpenClaw 路径。
- Factor Panel 使用五指数共同最新交易日，而不是日历“今天”。
- `--manual-data` 仍保留，但必须含 `source` 与 `review_status=APPROVED`。
- demo/example 自动隔离，不可作为 Production 输入。
- 抓取失败可保留 last-good；是否允许正式建议由 Freshness/Source Gate 决定。
- 北向旧口径按历史/retired/non-blocking 管理。
- 只有 `FORMAL_ADVICE_AVAILABLE=true` 才允许输出正式当前建议。

### 手工补数最小字段
`entity,feature,observation_date,release_date,available_date,value,source,review_status`

### 版本治理
- Production: V7.5.1-RC2
- OOS Challenger: V7.28.4
- Research Shadow: V7.28.5 Gate-2Confirm
