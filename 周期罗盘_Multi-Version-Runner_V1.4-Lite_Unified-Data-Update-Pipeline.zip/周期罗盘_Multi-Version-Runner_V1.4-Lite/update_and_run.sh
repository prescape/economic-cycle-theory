#!/bin/bash
python3 update_data.py "$@"
