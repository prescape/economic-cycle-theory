#!/usr/bin/env python3
"""V1.3 PIT source repair.
- purge demo/example/synthetic/mock from production components
- append verified official GDP/M2/credit last-good seed (only when newer than existing real data)
- rebuild current turnover proxy from daily amount
- rebuild flow amount/MA20 proxy from market PIT
- preserve legacy northbound history but mark it non-required/retired in registry
- rebuild unified_pit from production components only
"""
from pathlib import Path
import argparse, json, subprocess, sys
import pandas as pd
import numpy as np

FILES=['macro_pit.csv','market_pit.csv','valuation_pit.csv','flow_pit.csv','policy_pit.csv','earnings_pit.csv']
BAD=('demo','example','synthetic','mock')
ASSETS=['000300','000852','399006','000688','000016']

def norm(s):
    x=str(s).strip()
    if x.endswith('.0') and x[:-2].isdigit(): x=x[:-2]
    return x.zfill(6) if x.isdigit() and len(x)<6 else x

def clean(d):
    if d.empty:return d
    src=d.get('source',pd.Series('',index=d.index)).astype(str).str.lower()
    mask=pd.Series(False,index=d.index)
    for t in BAD: mask |= src.str.contains(t,na=False)
    return d.loc[~mask].copy()

def upsert(base,new):
    if new.empty:return base
    cols=set(base.columns)|set(new.columns)
    for c in cols:
        if c not in base: base[c]=''
        if c not in new: new[c]=''
    key=['entity','feature','observation_date','available_date']
    out=pd.concat([base[list(cols)],new[list(cols)]],ignore_index=True)
    out=out.drop_duplicates(key,keep='last')
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--pit-dir',required=True); ap.add_argument('--config-dir',required=True); ap.add_argument('--report',required=True); args=ap.parse_args()
    pit=Path(args.pit_dir); cfg=Path(args.config_dir); report=Path(args.report); report.parent.mkdir(parents=True,exist_ok=True)
    stats={}
    frames={}
    for fn in FILES:
        p=pit/fn
        d=pd.read_csv(p,low_memory=False,dtype={'entity':str}) if p.exists() else pd.DataFrame()
        before=len(d); d=clean(d); stats[fn]={'rows_before':before,'rows_after_real_only':len(d),'removed_nonproduction':before-len(d)}; frames[fn]=d

    # Try dynamic PBOC official fetch, then verified official seed supplies a last-good floor.
    dynamic=pit/'_pbc_official_dynamic.csv'
    fetcher=Path(__file__).with_name('fetch_pbc_official_latest.py')
    p=subprocess.run([sys.executable,str(fetcher),'--out',str(dynamic)],capture_output=True,text=True)
    stats['pbc_dynamic']={'pass':p.returncode==0,'stderr':p.stderr[-1000:]}
    extra=[]
    if dynamic.exists():
        try: extra.append(pd.read_csv(dynamic,dtype={'entity':str}))
        except: pass
        dynamic.unlink(missing_ok=True)
    seed=pd.read_csv(cfg/'verified_official_seed_v13.csv',dtype={'entity':str})
    extra.append(seed)
    official=pd.concat(extra,ignore_index=True) if extra else pd.DataFrame()
    official['entity']=official.entity.map(norm)
    frames['macro_pit.csv']=upsert(frames['macro_pit.csv'],official)

    # Market: current amount-derived turnover proxy, replacing stale/old proxy rows for same dates.
    m=frames['market_pit.csv'].copy(); m['entity']=m.entity.map(norm); m['observation_date']=pd.to_datetime(m.observation_date,errors='coerce')
    amt=m[(m.feature=='amount') & m.entity.isin(ASSETS)].copy()
    turn=[]
    for _,r in amt.iterrows():
        turn.append({'entity':r.entity,'feature':'turnover_proxy','observation_date':r.observation_date.strftime('%Y-%m-%d'),
                     'release_date':r.observation_date.strftime('%Y-%m-%d'),'available_date':r.observation_date.strftime('%Y-%m-%d'),
                     'revision_date':'','value':float(r.value)/1e10,'source':'derived_proxy_amount','data_quality':'C'})
    m=m[m.feature!='turnover_proxy'].copy(); m['observation_date']=m.observation_date.dt.strftime('%Y-%m-%d')
    frames['market_pit.csv']=upsert(m,pd.DataFrame(turn))

    # Flow: retain real historical flows, refresh amount_ratio_vs_ma20 from current market amount.
    f=frames['flow_pit.csv'].copy();
    if not f.empty: f['entity']=f.entity.map(norm); f=f[f.feature!='amount_ratio_vs_ma20'].copy()
    mp=frames['market_pit.csv'].copy(); mp['entity']=mp.entity.map(norm); mp['observation_date']=pd.to_datetime(mp.observation_date,errors='coerce')
    apx=[]
    for a in ASSETS:
        q=mp[(mp.entity==a)&(mp.feature=='amount')].copy().sort_values('observation_date')
        q['value']=pd.to_numeric(q.value,errors='coerce'); q=q.dropna(subset=['value']).drop_duplicates('observation_date',keep='last')
        q['ma20']=q.value.rolling(20).mean(); q['ratio']=q.value/q.ma20-1
        for _,r in q.dropna(subset=['ratio']).iterrows():
            ds=r.observation_date.strftime('%Y-%m-%d')
            apx.append({'entity':a,'feature':'amount_ratio_vs_ma20','observation_date':ds,'release_date':ds,'available_date':ds,
                        'revision_date':'','value':float(r.ratio),'source':'derived_market_amount','data_quality':'C'})
    frames['flow_pit.csv']=upsert(f,pd.DataFrame(apx))

    # write components + rebuilt unified; example_pit deliberately excluded.
    parts=[]
    for fn in FILES:
        d=frames[fn]
        d.to_csv(pit/fn,index=False)
        parts.append(d)
    unified=pd.concat(parts,ignore_index=True,sort=False)
    unified=clean(unified)
    unified.to_csv(pit/'unified_pit.csv',index=False)
    ex=pit/'example_pit.csv'
    if ex.exists():
        quarantine=pit/'quarantine'; quarantine.mkdir(exist_ok=True)
        ex.replace(quarantine/'example_pit.csv')
        stats['example_pit']='QUARANTINED'
    stats['unified_rows']=len(unified)
    report.write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(stats,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
