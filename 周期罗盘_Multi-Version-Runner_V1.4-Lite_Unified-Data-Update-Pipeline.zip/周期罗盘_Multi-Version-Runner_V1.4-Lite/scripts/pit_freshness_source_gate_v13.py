#!/usr/bin/env python3
from pathlib import Path
import argparse,json
import pandas as pd

ASSETS=['000300','000852','399006','000688','000016']
def norm(s):
    x=str(s).strip();
    if x.endswith('.0') and x[:-2].isdigit():x=x[:-2]
    return x.zfill(6) if x.isdigit() and len(x)<6 else x

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pit-dir',required=True);ap.add_argument('--registry',required=True);ap.add_argument('--output',required=True);ap.add_argument('--as-of',default=None);args=ap.parse_args()
    asof=pd.Timestamp(args.as_of) if args.as_of else pd.Timestamp.now().normalize()
    reg=json.loads(Path(args.registry).read_text(encoding='utf-8'))
    pit=Path(args.pit_dir); files=list(pit.glob('*_pit.csv'))
    parts=[]
    for p in files:
        if p.name=='example_pit.csv':continue
        try: parts.append(pd.read_csv(p,low_memory=False,dtype={'entity':str}))
        except: pass
    d=pd.concat(parts,ignore_index=True,sort=False) if parts else pd.DataFrame()
    d['entity']=d.entity.map(norm);d['observation_date']=pd.to_datetime(d.observation_date,errors='coerce');d['available_date']=pd.to_datetime(d.available_date,errors='coerce')
    bad_tokens=reg['forbidden_source_tokens']; checks=[]
    src=d.get('source',pd.Series('',index=d.index)).astype(str).str.lower()
    bad=pd.Series(False,index=d.index)
    for t in bad_tokens:bad|=src.str.contains(t,na=False)
    checks.append({'check':'no_demo_example_in_production','pass':not bool(bad.any()),'detail':f'bad_rows={int(bad.sum())}'})
    checks.append({'check':'example_pit_not_in_root','pass':not (pit/'example_pit.csv').exists(),'detail':'example_pit must be quarantined'})

    for feat,spec in reg['features'].items():
        if spec.get('cadence')=='retired':
            checks.append({'check':f'{feat}:retired_nonblocking','pass':True,'detail':spec.get('status')});continue
        if not spec.get('required'):continue
        q=d[(d.feature==feat)&(d.available_date<=asof)].copy()
        if feat in ('close','amount','turnover_proxy','relative_valuation','amount_ratio_vs_ma20'):
            latest={a:q[q.entity==a].observation_date.max() for a in ASSETS}
            missing=[a for a,v in latest.items() if pd.isna(v)]
            maxage=max([(asof-v).days for v in latest.values() if pd.notna(v)],default=9999)
            fresh=not missing and maxage<=spec['max_age_days']
            detail=f'latest_by_asset={{{", ".join(f"{a}:{latest[a].date() if pd.notna(latest[a]) else None}" for a in ASSETS)}}}; max_age={maxage}d'
            qsrc=q[q.entity.isin(ASSETS)]
        else:
            latest=q.observation_date.max(); qlatest=q[q.observation_date==latest] if pd.notna(latest) else q; latest_av=qlatest.available_date.max() if len(qlatest) else pd.NaT; age=9999 if pd.isna(latest_av) else (asof-latest_av).days; fresh=age<=spec['max_age_days']; detail=f'latest_observation={latest.date() if pd.notna(latest) else None}; latest_available={latest_av.date() if pd.notna(latest_av) else None}; release_age={age}d'
            qsrc=qlatest
        allowed=spec.get('allowed_sources',[])
        source_ok=True
        if allowed and len(qsrc):
            vals=qsrc.source.astype(str).unique().tolist()
            source_ok=all(any(v==a or v.startswith(a) for a in allowed) for v in vals)
            detail+=f'; sources={vals}'
        checks.append({'check':f'{feat}:freshness','pass':bool(fresh),'detail':detail})
        checks.append({'check':f'{feat}:source_quality','pass':bool(source_ok),'detail':detail})
    passed=sum(c['pass'] for c in checks);grade='PASS' if passed==len(checks) else 'FAIL'
    out={'version':'V1.3 PIT Freshness + Source Quality Gate','as_of':asof.date().isoformat(),'grade':grade,'checks_passed':passed,'checks_total':len(checks),'checks':checks}
    Path(args.output).parent.mkdir(parents=True,exist_ok=True);Path(args.output).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(0 if grade=='PASS' else 2)
if __name__=='__main__':main()
