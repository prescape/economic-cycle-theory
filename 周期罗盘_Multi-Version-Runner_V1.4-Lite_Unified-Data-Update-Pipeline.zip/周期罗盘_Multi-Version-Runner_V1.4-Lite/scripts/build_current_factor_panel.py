#!/usr/bin/env python3
from pathlib import Path
import argparse,json,pandas as pd,numpy as np
ASSETS=['000300','000852','399006','000688','000016']
def norm(x):
 s=str(x).strip();
 if s.endswith('.0') and s[:-2].isdigit(): s=s[:-2]
 if s.isdigit() and len(s)<6:s=s.zfill(6)
 return s
def load(p):
 d=pd.read_csv(p,low_memory=False,dtype={'entity':str});d['entity']=d.entity.map(norm);d['observation_date']=pd.to_datetime(d.observation_date,errors='coerce');d['available_date']=pd.to_datetime(d.available_date,errors='coerce');d['value']=pd.to_numeric(d.value,errors='coerce');return d
def series(d,a,f,asof):
 q=d[(d.entity==a)&(d.feature==f)&(d.available_date<=asof)&(d.observation_date<=asof)].dropna(subset=['value']).sort_values(['observation_date','available_date']).drop_duplicates('observation_date',keep='last');return q.set_index('observation_date').value.astype(float)
def snap(v,m,asof):
 rv={};ar={}
 for a in ASSETS:
  q=series(v,a,'relative_valuation',asof);s=series(m,a,'amount',asof)
  if q.empty or len(s)<20:raise RuntimeError(f'missing factor input {a} @ {asof.date()}')
  rv[a]=float(q.iloc[-1]);ar[a]=float(s.iloc[-1]/s.iloc[-20:].mean()-1)
 rv=pd.Series(rv);ar=pd.Series(ar);val=1-2*(rv.rank(method='average',ascending=True)-1)/5;flow=.12*(3-ar.rank(method='average',ascending=False));alpha=.55*val+.45*flow
 return pd.DataFrame([{'asset':a,'valuation':val[a],'flow':flow[a],'alpha_v75':alpha[a],'raw_relative_valuation':rv[a],'amount_ratio_vs_ma20':ar[a],'valuation_available':1,'flow_available':1} for a in ASSETS])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--pit-dir',required=True);ap.add_argument('--frozen-panel',required=True);ap.add_argument('--out-dir',required=True);ap.add_argument('--as-of');a=ap.parse_args();pit=Path(a.pit_dir);out=Path(a.out_dir);out.mkdir(parents=True,exist_ok=True);v=load(pit/'valuation_pit.csv');m=load(pit/'market_pit.csv');frozen=pd.read_csv(a.frozen_panel,dtype={'asset':str});frozen.asset=frozen.asset.map(norm);frozen.as_of_date=pd.to_datetime(frozen.as_of_date)
 if a.as_of: asof=pd.Timestamp(a.as_of)
 else:
  mx=[series(m,x,'close',pd.Timestamp('2100-01-01')).index.max() for x in ASSETS];asof=min(mx)
 x=snap(v,m,asof);x.insert(0,'as_of_date',asof.date().isoformat());x.to_csv(out/'current_factor_panel.csv',index=False,encoding='utf-8-sig')
 checks=[]
 for dt,g in frozen.groupby('as_of_date'):
  if len(g)!=5:continue
  try:y=snap(v,m,dt).set_index('asset')
  except:continue
  gg=g.set_index('asset').reindex(ASSETS);true=.55*gg.valuation+.45*gg.flow;pred=y.alpha_v75
  checks.append({'as_of_date':dt.date().isoformat(),'valuation_exact':bool(np.allclose(y.valuation.values,gg.valuation.values,atol=1e-9)),'alpha_order_exact':pred.sort_values(ascending=False).index.tolist()==true.sort_values(ascending=False).index.tolist(),'top1_exact':pred.idxmax()==true.idxmax()})
 au=pd.DataFrame(checks);au.to_csv(out/'factor_builder_historical_audit.csv',index=False,encoding='utf-8-sig');st={'current_as_of':asof.date().isoformat(),'comparable_nodes':len(au),'valuation_exact_rate':float(au.valuation_exact.mean()),'alpha_order_exact_rate':float(au.alpha_order_exact.mean()),'top1_exact_rate':float(au.top1_exact.mean()),'method':'allocation_equivalent_cross_sectional_builder','flow_note':'centered relative component only; common shift cancels in V7.5.1 ranking'};(out/'factor_builder_status.json').write_text(json.dumps(st,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(st,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
