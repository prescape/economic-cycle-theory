#!/usr/bin/env python3
"""Best-effort PBOC official web repair for M2 and AFRE-stock YoY.
No demo fallback. If official web parsing fails, exits non-zero; caller may retain last-good.
"""
import re, sys, json, argparse
from pathlib import Path
from datetime import datetime
import pandas as pd

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',required=True); args=ap.parse_args()
    try:
        import requests
        from bs4 import BeautifulSoup
    except Exception as e:
        print(f'[ERROR] requests/bs4 unavailable: {e}',file=sys.stderr); raise SystemExit(2)
    search='https://wzdig.pbc.gov.cn/search/pcRender'
    params={'pageId':'c177a85bd02b4114bebebd210809f691','q':'金融统计数据报告','sr':'date desc'}
    try:
        r=requests.get(search,params=params,timeout=20,headers={'User-Agent':'Mozilla/5.0'}); r.raise_for_status()
        soup=BeautifulSoup(r.text,'html.parser')
        candidates=[]
        for a in soup.find_all('a',href=True):
            title=' '.join(a.stripped_strings)
            m=re.search(r'(20\d{2})年(\d{1,2})月金融统计数据报告',title)
            if m:
                href=a['href']
                if href.startswith('/'): href='https://www.pbc.gov.cn'+href
                if href.startswith('http'): candidates.append((int(m.group(1)),int(m.group(2)),href,title))
        if not candidates: raise RuntimeError('no official report link found')
        y,m,url,title=max(candidates)
        p=requests.get(url,timeout=20,headers={'User-Agent':'Mozilla/5.0'}); p.raise_for_status()
        text=' '.join(BeautifulSoup(p.text,'html.parser').stripped_strings)
        mm2=re.search(r'广义货币[（(]M2[）)].{0,80}?同比增长\s*([\d.]+)%',text)
        mcr=re.search(r'社会融资规模存量.{0,80}?同比增长\s*([\d.]+)%',text)
        if not (mm2 and mcr): raise RuntimeError('M2/AFRE regex not matched')
        date_m=re.search(r'(20\d{2})[-年/.](\d{1,2})[-月/.](\d{1,2})',text[:1500])
        release=pd.Timestamp(datetime.now().date()) if not date_m else pd.Timestamp(int(date_m.group(1)),int(date_m.group(2)),int(date_m.group(3)))
        obs=pd.Timestamp(y,m,1)
        rows=[]
        for feat,val in [('M2_yoy',float(mm2.group(1))),('credit_yoy',float(mcr.group(1)))]:
            rows.append({'entity':'CN','feature':feat,'observation_date':obs.date(),'release_date':release.date(),
                         'available_date':release.date(),'revision_date':'','value':val,'source':'PBOC_OFFICIAL',
                         'data_quality':'A','source_url':url})
        pd.DataFrame(rows).to_csv(args.out,index=False)
        print(json.dumps({'status':'PASS','report':title,'url':url,'rows':rows},ensure_ascii=False,indent=2,default=str))
    except Exception as e:
        print(f'[ERROR] PBOC official fetch failed: {e}',file=sys.stderr); raise SystemExit(2)
if __name__=='__main__': main()
