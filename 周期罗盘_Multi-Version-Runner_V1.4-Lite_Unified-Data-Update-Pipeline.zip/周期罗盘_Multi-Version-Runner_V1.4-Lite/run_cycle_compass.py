#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import argparse,subprocess,sys,json,shutil
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'outputs';OUT.mkdir(exist_ok=True)
V751=ROOT/'versions'/'V7.5.1-RC2'/'dalio-china-asset-allocation';MODEL=V751/'data'/'pit';SHARED=ROOT/'shared_data'/'china_pit'

def run(c,cwd=None):return subprocess.run(c,cwd=cwd,capture_output=True,text=True)
def sync(src,dst):
    dst.mkdir(parents=True,exist_ok=True)
    for p in src.glob('*.csv'): shutil.copy2(p,dst/p.name)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--no-refresh',action='store_true');ap.add_argument('--as-of',default=None);args=ap.parse_args();rid=datetime.now().strftime('%Y%m%dT%H%M%S')
    sync(SHARED,MODEL)
    fetch_status='SKIPPED'
    if not args.no_refresh:
        p=run([sys.executable,str(V751/'scripts'/'fetch_all_pit.py')],cwd=str(V751));fetch_status='PASS' if p.returncode==0 else 'PARTIAL_OR_FAIL'
        sync(MODEL,SHARED)
    repair=run([sys.executable,str(ROOT/'scripts'/'repair_pit_sources_v13.py'),'--pit-dir',str(SHARED),'--config-dir',str(ROOT/'config'),'--report',str(OUT/f'{rid}_source_repair.json')])
    # push repaired components to model dir
    sync(SHARED,MODEL)
    gatefile=OUT/f'{rid}_freshness_source_gate.json'
    gatecmd=[sys.executable,str(ROOT/'scripts'/'pit_freshness_source_gate_v13.py'),'--pit-dir',str(SHARED),'--registry',str(ROOT/'config'/'source_registry_v13.json'),'--output',str(gatefile)]
    if args.as_of: gatecmd += ['--as-of',args.as_of]
    gate=run(gatecmd);gate_json=json.loads(gatefile.read_text(encoding='utf-8')) if gatefile.exists() else {'grade':'FAIL'}
    # V1.2 core can calculate only after the stricter source gate passes.
    if gate.returncode==0:
        core=run([sys.executable,str(ROOT/'run_cycle_compass_v12_core.py'),'--no-refresh'],cwd=str(ROOT))
        try: core_status=json.loads((OUT/'latest_runner_status.json').read_text(encoding='utf-8'))
        except: core_status={'ALL_3_VERSIONS_OK':'FAIL'}
    else:
        core_status={'ALL_3_VERSIONS_INVOKED':'BLOCKED','ALL_3_VERSIONS_OK':'FAIL','result':{'reason':'PIT Freshness/Source Quality Gate failed'}}
    final={'runner_version':'V1.3','run_id':rid,'PIT_FETCH_STATUS':fetch_status,'PIT_SOURCE_REPAIR_OK':repair.returncode==0,'PIT_FRESHNESS_SOURCE_GATE':gate_json.get('grade'),'ALL_3_VERSIONS_INVOKED':core_status.get('ALL_3_VERSIONS_INVOKED'),'ALL_3_VERSIONS_OK':core_status.get('ALL_3_VERSIONS_OK'),'FORMAL_ADVICE_AVAILABLE':gate.returncode==0 and core_status.get('ALL_3_VERSIONS_OK')=='PASS','core_result':core_status.get('result'),'governance':'No demo/example may enter production; northbound_net_inflow is retired/non-blocking after disclosure change; no strategy parameters changed.'}
    (OUT/'latest_runner_status.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(final,ensure_ascii=False,indent=2));raise SystemExit(0 if final['FORMAL_ADVICE_AVAILABLE'] else 2)
if __name__=='__main__':main()
