@echo off
python run_cycle_compass.py
pause
