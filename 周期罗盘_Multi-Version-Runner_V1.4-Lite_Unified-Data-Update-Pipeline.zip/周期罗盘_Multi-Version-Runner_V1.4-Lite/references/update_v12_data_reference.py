#!/usr/bin/env python3
"""
周期罗盘 V1.2 一键数据更新脚本
用法: python3 update_v12_data.py [--manual-data CSV_FILE]
"""

import subprocess
import sys
import shutil
import pandas as pd
from pathlib import Path
from datetime import datetime

ROOT = Path('/root/.openclaw/workspace/skills/周期罗盘_Multi-Version-Runner_V1.2-Lite')
V751 = ROOT / 'versions' / 'V7.5.1-RC2' / 'dalio-china-asset-allocation'
SHARED = ROOT / 'shared_data' / 'china_pit'
GEN = ROOT / 'shared_data' / 'generated'
FETCH = V751 / 'scripts' / 'fetch_all_pit.py'
BUILDER = ROOT / 'scripts' / 'build_current_factor_panel.py'
FROZEN = ROOT / 'shared_data' / 'reference' / 'V7.3_factor_panel_completed.csv'
RUNNER = ROOT / 'run_cycle_compass.py'

REQUIRED_FEATURES = {
    'PMI': {'source': 'NBS', 'freq': 'M', 'lag_days': 0},
    'CPI_yoy': {'source': 'NBS', 'freq': 'M', 'lag_days': 10},
    'PPI_yoy': {'source': 'NBS', 'freq': 'M', 'lag_days': 10},
    'M2_yoy': {'source': 'PBOC', 'freq': 'M', 'lag_days': 12},
    'credit_yoy': {'source': 'PBOC', 'freq': 'M', 'lag_days': 12},
    'new_loan_mom_bn': {'source': 'PBOC', 'freq': 'M', 'lag_days': 12},
    'GDP_yoy': {'source': 'NBS', 'freq': 'Q', 'lag_days': 18},
}

def run_cmd(cmd, cwd=None):
    """运行命令并返回结果"""
    print(f"\n{'='*60}")
    print(f"$ {' '.join(str(c) for c in cmd)}")
    print('='*60)
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if p.stdout: print(p.stdout)
    if p.stderr: print(p.stderr, file=sys.stderr)
    return p.returncode == 0, p.stdout, p.stderr

def step1_fetch_pit():
    """步骤1: 运行 fetch_all_pit.py 自动抓取"""
    print("\n" + "="*60)
    print("步骤 1/5: 自动抓取 PIT 数据")
    print("="*60)
    ok, _, _ = run_cmd([sys.executable, str(FETCH)], cwd=str(V751))
    if not ok:
        print("⚠️ fetch_all_pit.py 部分失败，继续用现有数据...")
    return ok

def step2_check_missing():
    """步骤2: 检查缺失数据"""
    print("\n" + "="*60)
    print("步骤 2/5: 检查数据缺失")
    print("="*60)
    
    pit_dir = V751 / 'data' / 'pit'
    macro_path = pit_dir / 'macro_pit.csv'
    
    if not macro_path.exists():
        print("❌ macro_pit.csv 不存在")
        return None
    
    df = pd.read_csv(macro_path)
    df['observation_date'] = pd.to_datetime(df['observation_date'])
    df['available_date'] = pd.to_datetime(df['available_date'])
    
    today = pd.Timestamp(datetime.now().date())
    missing = []
    
    for feat, meta in REQUIRED_FEATURES.items():
        fdf = df[df['feature'] == feat]
        if fdf.empty:
            missing.append({
                'feature': feat,
                'latest': '无数据',
                'needed': today.strftime('%Y-%m'),
                'source': meta['source']
            })
        else:
            latest = fdf['observation_date'].max()
            months_behind = (today.year - latest.year) * 12 + (today.month - latest.month)
            if months_behind > 1:
                missing.append({
                    'feature': feat,
                    'latest': latest.strftime('%Y-%m'),
                    'needed': today.strftime('%Y-%m'),
                    'source': meta['source'],
                    'months_behind': months_behind
                })
    
    if missing:
        print(f"\n⚠️ 发现 {len(missing)} 项数据缺失/滞后:")
        print(f"{'指标':<20} {'最新数据':<12} {'需要补充':<12} {'来源':<10} {'滞后月数'}")
        print("-" * 70)
        for m in missing:
            lag = m.get('months_behind', '-')
            print(f"{m['feature']:<20} {m['latest']:<12} {m['needed']:<12} {m['source']:<10} {lag}")
        
        print("\n💡 补充方法:")
        print("   1. 手动查询: 百度搜索 '中国 M2同比 2026年8月'、'社会融资规模 2026年7月'")
        print("   2. 数据填入: 创建 CSV 文件，格式如下:")
        print("      entity,feature,observation_date,release_date,available_date,revision_date,value,source,data_quality")
        print("      CN,M2_yoy,2026-07-01,2026-07-15,2026-07-15,,7.7,PBOC_manual,B")
        print("   3. 运行: python3 update_v12_data.py --manual-data your_data.csv")
    else:
        print("✅ 所有核心指标数据已更新到最新")
    
    return missing

def step3_sync():
    """步骤3: 同步到 shared_data"""
    print("\n" + "="*60)
    print("步骤 3/5: 同步到 shared_data/china_pit")
    print("="*60)
    
    pit_dir = V751 / 'data' / 'pit'
    SHARED.mkdir(parents=True, exist_ok=True)
    
    for f in pit_dir.glob('*.csv'):
        dest = SHARED / f.name
        shutil.copy2(f, dest)
        print(f"  ✅ {f.name} → shared_data/china_pit/")
    
    print("✅ 同步完成")

def step4_build_panel():
    """步骤4: 重建 Factor Panel"""
    print("\n" + "="*60)
    print("步骤 4/5: 重建 Factor Panel")
    print("="*60)
    
    today_str = datetime.now().strftime('%Y-%m-%d')
    ok, out, err = run_cmd([
        sys.executable, str(BUILDER),
        '--pit-dir', str(SHARED),
        '--frozen-panel', str(FROZEN),
        '--out-dir', str(GEN),
        '--as-of', today_str
    ])
    
    if ok:
        print("✅ Factor Panel 构建成功")
        # 显示结果
        panel = pd.read_csv(GEN / 'current_factor_panel.csv')
        print(f"\nFactor Panel (as-of: {panel.as_of_date.iloc[0]}):")
        print(panel.to_string(index=False))
    else:
        print("❌ Factor Panel 构建失败")
    return ok

def step5_run_compass():
    """步骤5: 运行周期罗盘"""
    print("\n" + "="*60)
    print("步骤 5/5: 运行周期罗盘")
    print("="*60)
    
    ok, out, err = run_cmd([sys.executable, str(RUNNER), '--no-refresh'])
    if ok:
        print("✅ 周期罗盘运行完成")
        # 显示关键结果
        import json
        status = json.loads((ROOT / 'outputs' / 'latest_runner_status.json').read_text())
        print(f"\nRun ID: {status['run_id']}")
        print(f"Regime: {status['result']['macro']['regime']}")
        print(f"Risk Allocation: {status['result']['macro']['risk_allocation']}")
        print(f"Factor Rank: {' > '.join(status['result']['factor_rank'])}")
    else:
        print("❌ 周期罗盘运行失败")
    return ok

def inject_manual_data(csv_path):
    """注入手动补充的数据"""
    print(f"\n{'='*60}")
    print(f"注入手动数据: {csv_path}")
    print('='*60)
    
    manual = pd.read_csv(csv_path)
    required = ['entity', 'feature', 'observation_date', 'release_date', 'available_date', 'value']
    if not all(c in manual.columns for c in required):
        print(f"❌ CSV 缺少必要列: {required}")
        return False
    
    # 追加到 unified_pit.csv
    unified_path = SHARED / 'unified_pit.csv'
    if unified_path.exists():
        existing = pd.read_csv(unified_path)
        combined = pd.concat([existing, manual], ignore_index=True)
        # 去重
        combined = combined.drop_duplicates(subset=['entity', 'feature', 'observation_date'], keep='last')
        combined.to_csv(unified_path, index=False)
        print(f"✅ 已注入 {len(manual)} 行数据，unified_pit 现有 {len(combined)} 行")
    else:
        manual.to_csv(unified_path, index=False)
        print(f"✅ 已创建 unified_pit.csv，{len(manual)} 行")
    
    # 同时更新对应的组件文件
    for feat in manual['feature'].unique():
        feat_rows = manual[manual['feature'] == feat]
        # 映射到组件文件
        component_map = {
            'PMI': 'macro_pit.csv', 'CPI_yoy': 'macro_pit.csv', 'PPI_yoy': 'macro_pit.csv',
            'M2_yoy': 'macro_pit.csv', 'credit_yoy': 'macro_pit.csv', 'new_loan_mom_bn': 'macro_pit.csv',
            'GDP_yoy': 'macro_pit.csv',
        }
        comp = component_map.get(feat)
        if comp:
            comp_path = SHARED / comp
            if comp_path.exists():
                comp_df = pd.read_csv(comp_path)
                comp_df = pd.concat([comp_df, feat_rows], ignore_index=True)
                comp_df = comp_df.drop_duplicates(subset=['entity', 'feature', 'observation_date'], keep='last')
                comp_df.to_csv(comp_path, index=False)
                print(f"  ✅ 已更新 {comp}: {feat} +{len(feat_rows)}行")
    
    return True

def main():
    import argparse
    ap = argparse.ArgumentParser(description='周期罗盘 V1.2 一键数据更新')
    ap.add_argument('--manual-data', help='手动补充数据 CSV 文件路径')
    ap.add_argument('--skip-fetch', action='store_true', help='跳过自动抓取')
    ap.add_argument('--skip-check', action='store_true', help='跳过缺失检查')
    args = ap.parse_args()
    
    print("="*60)
    print("周期罗盘 V1.2 数据更新流水线")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60)
    
    # 注入手动数据（如果有）
    if args.manual_data:
        inject_manual_data(args.manual_data)
    
    # 步骤1: 自动抓取
    if not args.skip_fetch:
        step1_fetch_pit()
    
    # 步骤2: 检查缺失
    if not args.skip_check:
        missing = step2_check_missing()
    
    # 步骤3: 同步
    step3_sync()
    
    # 步骤4: 重建 Factor Panel
    if not step4_build_panel():
        print("\n⚠️ Factor Panel 构建失败，尝试不带 --as-of...")
        run_cmd([sys.executable, str(BUILDER), '--pit-dir', str(SHARED), '--frozen-panel', str(FROZEN), '--out-dir', str(GEN)])
    
    # 步骤5: 运行周期罗盘
    step5_run_compass()
    
    print("\n" + "="*60)
    print(f"完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*60)

if __name__ == '__main__':
    main()
