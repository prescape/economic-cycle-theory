#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
周期罗盘 Multi-Version Runner V1.3 一键数据更新器
参考 update_v12_data.py 的五步流水线，但执行 V1.3 real-source-only 治理。

用法:
  python update_v13_data.py
  python update_v13_data.py --skip-fetch
  python update_v13_data.py --as-of 2026-08-28
  python update_v13_data.py --manual-data supplement.csv

手动数据不会无条件进入 Production：必须通过字段、source whitelist、forbidden token 校验。
"""
from pathlib import Path
from datetime import datetime
import argparse, subprocess, sys, shutil, json
import pandas as pd

ROOT=Path(__file__).resolve().parent
V751=ROOT/'versions'/'V7.5.1-RC2'/'dalio-china-asset-allocation'
MODEL=V751/'data'/'pit'
SHARED=ROOT/'shared_data'/'china_pit'
GEN=ROOT/'shared_data'/'generated'
FETCH=V751/'scripts'/'fetch_all_pit.py'
REPAIR=ROOT/'scripts'/'repair_pit_sources_v13.py'
GATE=ROOT/'scripts'/'pit_freshness_source_gate_v13.py'
BUILDER=ROOT/'scripts'/'build_current_factor_panel.py'
FROZEN=ROOT/'shared_data'/'reference'/'V7.3_factor_panel_completed.csv'
RUNNER=ROOT/'run_cycle_compass.py'
REGISTRY=ROOT/'config'/'source_registry_v13.json'


def run_cmd(cmd,cwd=None):
    print('\n'+'='*72); print('$ '+' '.join(map(str,cmd))); print('='*72)
    p=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True)
    if p.stdout: print(p.stdout)
    if p.stderr: print(p.stderr,file=sys.stderr)
    return p


def sync(src,dst):
    dst.mkdir(parents=True,exist_ok=True)
    for p in src.glob('*.csv'):
        if p.name.startswith('_'): continue
        shutil.copy2(p,dst/p.name)


def validate_manual(path):
    reg=json.loads(REGISTRY.read_text(encoding='utf-8'))
    manual=pd.read_csv(path,dtype={'entity':str,'source':str})
    required=['entity','feature','observation_date','release_date','available_date','value','source']
    miss=[c for c in required if c not in manual.columns]
    if miss: raise ValueError(f'manual CSV missing columns: {miss}')
    forbidden=[x.lower() for x in reg.get('forbidden_source_tokens',[])]
    errors=[]
    for i,r in manual.iterrows():
        feat=str(r.feature); src=str(r.source)
        if any(t in src.lower() for t in forbidden): errors.append(f'row {i}: forbidden source {src}')
        meta=reg.get('features',{}).get(feat)
        if not meta: errors.append(f'row {i}: unregistered feature {feat}')
        elif meta.get('allowed_sources') and src not in meta['allowed_sources']:
            errors.append(f'row {i}: source {src} not allowed for {feat}')
    if errors: raise ValueError('; '.join(errors[:20]))
    return manual


def inject_manual(path):
    manual=validate_manual(path)
    component_map={
      'PMI':'macro_pit.csv','CPI_yoy':'macro_pit.csv','PPI_yoy':'macro_pit.csv','M2_yoy':'macro_pit.csv',
      'credit_yoy':'macro_pit.csv','new_loan_mom_bn':'macro_pit.csv','GDP_yoy':'macro_pit.csv',
      'close':'market_pit.csv','amount':'market_pit.csv','relative_valuation':'valuation_pit.csv',
      'southbound_net_inflow':'flow_pit.csv','earnings_revision_1m':'earnings_pit.csv','LPR_1Y':'policy_pit.csv'
    }
    for fn,g in manual.groupby(manual.feature.map(component_map)):
        if pd.isna(fn): continue
        p=SHARED/str(fn)
        base=pd.read_csv(p,dtype={'entity':str}) if p.exists() else pd.DataFrame(columns=manual.columns)
        for c in set(base.columns)|set(g.columns):
            if c not in base: base[c]=''
            if c not in g: g[c]=''
        out=pd.concat([base,g],ignore_index=True,sort=False)
        keys=['entity','feature','observation_date','available_date']
        out=out.drop_duplicates(keys,keep='last')
        out.to_csv(p,index=False)
        print(f'  validated manual supplement -> {fn}: +{len(g)}')


def print_missing(asof=None):
    reg=json.loads(REGISTRY.read_text(encoding='utf-8'))
    now=pd.Timestamp(asof or datetime.now().date())
    files=['macro_pit.csv','market_pit.csv','valuation_pit.csv','flow_pit.csv','policy_pit.csv','earnings_pit.csv']
    frames=[]
    for fn in files:
        p=SHARED/fn
        if p.exists():
            d=pd.read_csv(p,low_memory=False,dtype={'entity':str}); d['_file']=fn; frames.append(d)
    if not frames: return
    allp=pd.concat(frames,ignore_index=True,sort=False)
    allp['available_date']=pd.to_datetime(allp.available_date,errors='coerce')
    allp['observation_date']=pd.to_datetime(allp.observation_date,errors='coerce')
    print('\nCore PIT freshness/source overview:')
    print(f"{'feature':<24}{'latest_available':<18}{'latest_obs':<14}{'required':<10}{'status'}")
    print('-'*80)
    for feat,meta in reg.get('features',{}).items():
        q=allp[allp.feature==feat]
        req=meta.get('required',False)
        if meta.get('cadence')=='retired':
            print(f'{feat:<24}{"RETIRED":<18}{"-":<14}{str(req):<10}NON_BLOCKING'); continue
        if q.empty:
            st='MISSING' if req else 'OPTIONAL_MISSING'; la=lo='-'
        else:
            la=q.available_date.max(); lo=q.observation_date.max()
            age=(now-la).days if pd.notna(la) else 99999
            max_age=meta.get('max_age_days')
            st='OK' if (max_age is None or age<=max_age) else 'STALE'
            la=str(la.date()) if pd.notna(la) else '-'; lo=str(lo.date()) if pd.notna(lo) else '-'
        print(f'{feat:<24}{la:<18}{lo:<14}{str(req):<10}{st}')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--manual-data')
    ap.add_argument('--skip-fetch',action='store_true')
    ap.add_argument('--as-of',default=None)
    args=ap.parse_args()
    rid=datetime.now().strftime('%Y%m%dT%H%M%S')
    print('='*72); print('周期罗盘 V1.3 PIT Data Update Pipeline'); print('Run ID:',rid); print('='*72)

    sync(SHARED,MODEL)
    if args.manual_data:
        print('\nStep 0: validate manual supplement')
        inject_manual(args.manual_data); sync(SHARED,MODEL)

    print('\nStep 1/6: fetch real PIT sources')
    if args.skip_fetch: print('SKIPPED')
    else: run_cmd([sys.executable,str(FETCH)],cwd=str(V751)); sync(MODEL,SHARED)

    print('\nStep 2/6: V1.3 source repair + quarantine demo/example')
    repair_report=ROOT/'outputs'/f'{rid}_update_source_repair.json'
    p=run_cmd([sys.executable,str(REPAIR),'--pit-dir',str(SHARED),'--config-dir',str(ROOT/'config'),'--report',str(repair_report)])
    if p.returncode: raise SystemExit(2)
    sync(SHARED,MODEL)

    print('\nStep 3/6: missing/freshness diagnostic')
    print_missing(args.as_of)

    print('\nStep 4/6: hard Freshness + Source Quality Gate')
    gate_report=ROOT/'outputs'/f'{rid}_update_gate.json'
    cmd=[sys.executable,str(GATE),'--pit-dir',str(SHARED),'--registry',str(REGISTRY),'--output',str(gate_report)]
    if args.as_of: cmd += ['--as-of',args.as_of]
    gate=run_cmd(cmd)
    if gate.returncode:
        print('BLOCKED: production gate failed; Factor Panel/strategy execution will not be treated as formal advice.')
        raise SystemExit(2)

    print('\nStep 5/6: rebuild current Factor Panel')
    bcmd=[sys.executable,str(BUILDER),'--pit-dir',str(SHARED),'--frozen-panel',str(FROZEN),'--out-dir',str(GEN)]
    if args.as_of: bcmd += ['--as-of',args.as_of]
    bp=run_cmd(bcmd)
    if bp.returncode: raise SystemExit(2)

    print('\nStep 6/6: run V1.3 three-track compass')
    rcmd=[sys.executable,str(RUNNER),'--no-refresh']
    if args.as_of: rcmd += ['--as-of',args.as_of]
    rp=run_cmd(rcmd,cwd=str(ROOT))
    raise SystemExit(rp.returncode)

if __name__=='__main__': main()
