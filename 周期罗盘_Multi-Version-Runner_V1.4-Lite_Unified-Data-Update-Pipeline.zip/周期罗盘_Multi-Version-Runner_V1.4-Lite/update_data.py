#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""周期罗盘 Multi-Version Runner V1.4 — Unified Data Update Pipeline.

Only upgrades data orchestration. Strategy parameters are unchanged.
"""
from pathlib import Path
from datetime import datetime
import argparse, subprocess, sys, shutil, json
import pandas as pd

ROOT = Path(__file__).resolve().parent
V751 = ROOT / 'versions' / 'V7.5.1-RC2' / 'dalio-china-asset-allocation'
MODEL_PIT = V751 / 'data' / 'pit'
SHARED = ROOT / 'shared_data' / 'china_pit'
GEN = ROOT / 'shared_data' / 'generated'
OUT = ROOT / 'outputs'
FETCH = V751 / 'scripts' / 'fetch_all_pit.py'
REPAIR = ROOT / 'scripts' / 'repair_pit_sources_v13.py'
GATE = ROOT / 'scripts' / 'pit_freshness_source_gate_v13.py'
REGISTRY = ROOT / 'config' / 'source_registry_v13.json'
BUILDER = ROOT / 'scripts' / 'build_current_factor_panel.py'
FROZEN = ROOT / 'shared_data' / 'reference' / 'V7.3_factor_panel_completed.csv'
CORE = ROOT / 'run_cycle_compass_v12_core.py'
ASSETS = ['000300','000852','399006','000688','000016']

def run_cmd(cmd, cwd=None):
    print('\n$ ' + ' '.join(map(str, cmd)))
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if p.stdout: print(p.stdout)
    if p.stderr: print(p.stderr, file=sys.stderr)
    return p

def sync(src, dst):
    dst.mkdir(parents=True, exist_ok=True)
    for p in src.glob('*.csv'):
        if p.name == 'example_pit.csv':
            continue
        shutil.copy2(p, dst / p.name)

def inject_manual(csv_path):
    """Manual data is emergency-only and must be explicitly APPROVED."""
    manual = pd.read_csv(csv_path, dtype={'entity': str})
    required = ['entity','feature','observation_date','release_date','available_date','value','source','review_status']
    missing = [c for c in required if c not in manual.columns]
    if missing:
        raise ValueError(f'manual-data missing columns: {missing}')
    if not (manual['review_status'].astype(str).str.upper() == 'APPROVED').all():
        raise ValueError('manual-data contains non-APPROVED rows; rejected from Production')
    if 'is_manual' not in manual.columns:
        manual['is_manual'] = True
    if 'retrieved_at' not in manual.columns:
        manual['retrieved_at'] = datetime.now().isoformat(timespec='seconds')
    component_map = {
        'PMI':'macro_pit.csv','CPI_yoy':'macro_pit.csv','PPI_yoy':'macro_pit.csv',
        'M2_yoy':'macro_pit.csv','credit_yoy':'macro_pit.csv','new_loan_mom_bn':'macro_pit.csv',
        'GDP_yoy':'macro_pit.csv'
    }
    SHARED.mkdir(parents=True, exist_ok=True)
    for feat, rows in manual.groupby('feature'):
        comp = component_map.get(feat)
        if not comp:
            raise ValueError(f'unsupported manual production feature: {feat}')
        p = SHARED / comp
        old = pd.read_csv(p, low_memory=False, dtype={'entity': str}) if p.exists() else pd.DataFrame()
        combined = pd.concat([old, rows], ignore_index=True, sort=False)
        combined = combined.drop_duplicates(['entity','feature','observation_date'], keep='last')
        combined.to_csv(p, index=False)
        print(f'APPROVED manual rows: {feat} +{len(rows)}')

def latest_common_trading_day():
    p = SHARED / 'market_pit.csv'
    d = pd.read_csv(p, low_memory=False, dtype={'entity': str})
    d['entity'] = d['entity'].astype(str).str.replace('.0','',regex=False).str.zfill(6)
    d['observation_date'] = pd.to_datetime(d['observation_date'], errors='coerce')
    q = d[(d['feature'] == 'close') & d['entity'].isin(ASSETS)]
    latest = {}
    for a in ASSETS:
        s = q.loc[q.entity == a, 'observation_date'].dropna()
        if s.empty:
            raise RuntimeError(f'missing close data for {a}')
        latest[a] = s.max()
    return min(latest.values()), latest

def main():
    ap = argparse.ArgumentParser(description='周期罗盘 V1.4 一键数据更新与三版本运行')
    ap.add_argument('--manual-data', help='APPROVED 手工补数 CSV')
    ap.add_argument('--skip-fetch', action='store_true')
    ap.add_argument('--as-of', help='仅用于门禁审计；默认今天')
    args = ap.parse_args()
    OUT.mkdir(exist_ok=True); GEN.mkdir(parents=True, exist_ok=True)
    rid = datetime.now().strftime('%Y%m%dT%H%M%S')

    # 0. last-good seed + optional approved manual data
    sync(SHARED, MODEL_PIT)
    if args.manual_data:
        inject_manual(args.manual_data)
        sync(SHARED, MODEL_PIT)

    # 1. Fetch
    fetch_status = 'SKIPPED'
    if not args.skip_fetch:
        p = run_cmd([sys.executable, str(FETCH)], cwd=str(V751))
        fetch_status = 'PASS' if p.returncode == 0 else 'PARTIAL_OR_FAIL'
        sync(MODEL_PIT, SHARED)

    # 2. Repair sources + quarantine demo/example + derive turnover/flow proxy + rebuild unified
    repair_report = OUT / f'{rid}_source_repair.json'
    p = run_cmd([sys.executable, str(REPAIR), '--pit-dir', str(SHARED),
                 '--config-dir', str(ROOT/'config'), '--report', str(repair_report)])
    repair_ok = p.returncode == 0
    sync(SHARED, MODEL_PIT)

    # 3. Freshness + source-quality gate
    gate_file = OUT / f'{rid}_freshness_source_gate.json'
    cmd = [sys.executable, str(GATE), '--pit-dir', str(SHARED),
           '--registry', str(REGISTRY), '--output', str(gate_file)]
    if args.as_of:
        cmd += ['--as-of', args.as_of]
    gp = run_cmd(cmd)
    gate_json = json.loads(gate_file.read_text(encoding='utf-8')) if gate_file.exists() else {'grade':'FAIL'}

    # 4. Determine latest common trading day (never blindly use calendar today)
    common_day, latest_by_asset = latest_common_trading_day()

    # 5. Build current factor panel for that trading day
    bp = run_cmd([sys.executable, str(BUILDER), '--pit-dir', str(SHARED),
                  '--frozen-panel', str(FROZEN), '--out-dir', str(GEN),
                  '--as-of', common_day.strftime('%Y-%m-%d')])
    build_ok = bp.returncode == 0

    # 6. Run all three versions only when data gate + factor build pass
    core_status = {'ALL_3_VERSIONS_INVOKED':'BLOCKED','ALL_3_VERSIONS_OK':'FAIL'}
    if gp.returncode == 0 and build_ok:
        cp = run_cmd([sys.executable, str(CORE), '--no-refresh'], cwd=str(ROOT))
        try:
            core_status = json.loads((OUT/'latest_runner_status.json').read_text(encoding='utf-8'))
        except Exception:
            core_status = {'ALL_3_VERSIONS_INVOKED':'FAIL','ALL_3_VERSIONS_OK':'FAIL'}

    formal = (repair_ok and gp.returncode == 0 and build_ok and core_status.get('ALL_3_VERSIONS_OK') == 'PASS')
    final = {
        'runner_version':'V1.4', 'run_id':rid,
        'PIT_FETCH_STATUS':fetch_status,
        'PIT_SOURCE_REPAIR_OK':repair_ok,
        'PIT_FRESHNESS_SOURCE_GATE':gate_json.get('grade','FAIL'),
        'latest_common_trading_day':common_day.date().isoformat(),
        'latest_close_by_asset':{k:v.date().isoformat() for k,v in latest_by_asset.items()},
        'FACTOR_PANEL_BUILD_OK':build_ok,
        'ALL_3_VERSIONS_INVOKED':core_status.get('ALL_3_VERSIONS_INVOKED'),
        'ALL_3_VERSIONS_OK':core_status.get('ALL_3_VERSIONS_OK'),
        'FORMAL_ADVICE_AVAILABLE':formal,
        'governance':'No demo/example in Production; manual rows require APPROVED; strategy parameters unchanged.'
    }
    (OUT/'latest_v14_update_status.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(final,ensure_ascii=False,indent=2))
    raise SystemExit(0 if formal else 2)

if __name__ == '__main__':
    main()
