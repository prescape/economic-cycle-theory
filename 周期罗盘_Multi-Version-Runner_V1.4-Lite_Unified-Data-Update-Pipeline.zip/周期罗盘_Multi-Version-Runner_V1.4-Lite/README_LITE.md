# 周期罗盘 Multi-Version Runner V1.0 Lite

Lite版目标：保持三版本统一调用，但避免重复打包数据。

## 结构
- `shared_data/china_pit/`：三版本共享的一份中国PIT数据。
- `versions/V7.5.1-RC2/`：Production核心引擎、抓取脚本及必要历史输出。
- `versions/V7.28.4-OOS/`：OOS Challenger核心引擎、Ledger、关键审计输出。
- `versions/V7.28.5-Shadow/`：Gate-2Confirm Shadow核心引擎和研究输出。
- 删除了重复的 `frozen_sources/*.zip`、重复China PIT、全球风险历史归档及非运行必需的大型报告附件。

## 治理不变
V7.5.1-RC2仍是唯一Production。
V7.28.4仍是Frozen OOS Challenger。
V7.28.5仍是Research Shadow。
Lite化不改变任何策略参数。
