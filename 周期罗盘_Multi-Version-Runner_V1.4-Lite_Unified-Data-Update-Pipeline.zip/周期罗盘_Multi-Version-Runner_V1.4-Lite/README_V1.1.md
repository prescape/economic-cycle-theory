# 周期罗盘 Multi-Version Runner V1.1 Lite

闭环流程：PIT抓取 → Data Quality Gate → shared_data 同步 → 三版本同一 run_id 调度 → ALL_3_VERSIONS_INVOKED / ALL_3_VERSIONS_OK → 统一报告。

Windows: `run.bat`
Linux/macOS: `./run.sh`
严格模式: `python run_cycle_compass.py`
离线验收: `python run_cycle_compass.py --no-refresh --allow-stale`

注意：原 V7.5.1 冻结包的 Factor Panel 只到 2026-06，且没有正式的“最新 PIT → valuation/flow Factor Panel”构建器。因此 V1.1 会刷新并验证 PIT，但 Factor Panel 落后时会把三版本标记为 REFERENCE_ONLY，并令 ALL_3_VERSIONS_OK=FAIL；不会用历史仓位冒充当前投资建议。
