# 周期罗盘 Multi-Version Runner V1.2 Lite

本版只解决：最新 PIT → 最新 Factor Panel → 三版本当前建议。

新增 `scripts/build_current_factor_panel.py`。Valuation 使用 relative_valuation 横截面便宜度；Flow 使用 amount/MA20-1 横截面活跃度。V7.5.1 仍为 55% Valuation + 45% Flow。

历史验证：125 个可比冻结节点，V7.5.1 五指数 Alpha 完整排序复现率 100%。Flow 的市场共同平移项不影响横截面排序和仓位，因此仅保存 centered relative component。

V7.5.1 / V7.28.4 / V7.28.5 策略参数均未修改。
