# 周期罗盘 Multi-Version Runner V1.3 — PIT Data Source Repair

本版只修数据层，不修改 V7.5.1 / V7.28.4 / V7.28.5 的任何策略参数。

## 新闭环
`真实源抓取 → selective source repair → demo/example隔离 → Freshness Gate → Source Quality Gate → Factor Panel → 三版本当前建议`

## 修复项
- M2：AKShare失败时尝试人民银行官网搜索/报告解析；附带已核验 2026-07 last-good 官方锚点，未来过期会被 Gate 阻止。
- 社融/信用：同上，使用社融存量同比 `credit_yoy`。
- GDP：移除 demo；附带国家统计局 2026Q2 官方核算 last-good 锚点。
- turnover_proxy：统一由最新 `market_pit.amount` 日度重建，不再依赖陈旧独立 turnover 接口。
- Flow：`amount_ratio_vs_ma20` 由最新 market amount 重建；demo flow 禁止进入生产。
- 北向：`northbound_net_inflow` 自 2024-08-19 起按披露制度变化标记 RETIRED / non-blocking，不伪造后续净流入。
- `example_pit.csv`：移动到 `quarantine/`，`unified_pit.csv` 永不合并它。

## 严格门
正式建议必须同时满足：
- `PIT_SOURCE_REPAIR_OK = true`
- `PIT_FRESHNESS_SOURCE_GATE = PASS`
- `ALL_3_VERSIONS_OK = PASS`
- `FORMAL_ADVICE_AVAILABLE = true`

若真实源失败，保留 last-good 是允许的，但超过对应 freshness SLA 后正式建议自动 FAIL。
